TASK_SECTION_RULES = {
    "sampling": {
        "preferred_sections": ["participants", "sample", "sampling", "data collection", "method", "research design"],
        "keywords": ["sample", "participants", "respondents", "recruited", "recruitment", "sampling", "retained", "responses", "population"],
        "excluded_sections": ["references", "appendix"],
    },
    "methodology": {
        "preferred_sections": ["method", "methodology", "research design", "experimental design", "procedure", "data collection", "measurement", "participants"],
        "keywords": ["methodology", "research design", "experimental design", "survey", "questionnaire", "interview", "data collection", "procedure", "measurement", "experiment", "qualitative", "quantitative", "mixed methods"],
        "excluded_sections": ["references", "appendix", "future research", "future work", "limitations"],
    },
    "datasets": {
        "preferred_sections": ["data", "dataset", "sample", "participants", "data collection"],
        "keywords": ["dataset", "data source", "sample", "participants", "respondents", "observations", "records", "responses", "collected", "retained"],
        "excluded_sections": ["references", "appendix"],
    },
    "models": {
        "preferred_sections": ["model", "method", "architecture", "framework", "algorithm", "implementation"],
        "keywords": ["model", "algorithm", "architecture", "framework", "classifier", "embedding", "transformer", "neural network", "regression"],
        "excluded_sections": ["references", "appendix"],
    },
    "results": {
        "preferred_sections": ["results", "findings", "analysis", "evaluation", "results and discussion"],
        "keywords": ["result", "finding", "significant", "hypothesis", "effect", "outcome", "performance", "mediation", "moderation", "confidence interval", "p <", "β"],
        "excluded_sections": ["references", "appendix"],
    },
    "limitations": {
        "preferred_sections": ["limitations", "limitation", "discussion", "general discussion", "conclusion", "future research"],
        "keywords": ["limitation", "limited", "weakness", "constraint", "generalizability", "generalisation", "self-reported", "single country", "ecological validity", "scenario-based", "did not account", "not measured", "future research"],
        "excluded_sections": ["references", "appendix"],
    },
    "future_work": {
        "preferred_sections": ["future research", "future work", "limitations", "discussion", "conclusion", "recommendations"],
        "keywords": ["future research", "future work", "future studies", "further research", "should examine", "should explore", "could examine", "could explore", "recommend"],
        "excluded_sections": ["references", "appendix"],
    },
    "contributions": {
        "preferred_sections": ["contribution", "contributions", "discussion", "conclusion", "implications"],
        "keywords": ["contribution", "theoretical contribution", "practical contribution", "implications", "novel", "original"],
        "excluded_sections": ["references", "appendix"],
    },
    "variables": {
        "preferred_sections": ["conceptual model", "research model", "hypotheses", "measures", "measurement", "results"],
        "keywords": ["variable", "construct", "predictor", "dependent", "independent", "mediator", "moderator", "factor", "hypothesis"],
        "excluded_sections": ["references", "appendix"],
    },
    "literature_review": {
        "preferred_sections": ["literature review", "related work", "background", "theoretical background"],
        "keywords": ["previous research", "prior research", "prior studies", "literature", "existing studies"],
        "excluded_sections": ["references", "appendix"],
    },
    "question_answering": {"preferred_sections": [], "keywords": [], "excluded_sections": ["references", "appendix"]},
}
TASK_QUERY_EXPANSIONS = {k: " ".join(v["keywords"]) for k, v in TASK_SECTION_RULES.items()}
