from app.embeddings.embedder import EmbeddingModel

from app.vectorstore.chroma_store import ChromaVectorStore


class VectorRetriever:

    def __init__(
        self,
        top_k=5
    ):

        self.top_k = top_k

        self.embedder = EmbeddingModel()

        self.vector_store = ChromaVectorStore()

    # ========================================================
    # SEARCH
    # ========================================================

    def search(
        self,
        query,
        top_k=None,
        exclude_references=True
    ):

        # ----------------------------------------------------
        # 1. Encode query
        # ----------------------------------------------------

        query_embedding = (
            self.embedder.encode_query(
                query
            )
        )

        # ----------------------------------------------------
        # 2. Metadata filter
        # ----------------------------------------------------

        where_filter = None

        if exclude_references:

            where_filter = {
                "section": {
                    "$ne": "References"
                }
            }

        # ----------------------------------------------------
        # 3. Number of results
        # ----------------------------------------------------

        number_of_results = (

            top_k
            if top_k is not None
            else self.top_k

        )

        # ----------------------------------------------------
        # 4. Query ChromaDB
        # ----------------------------------------------------

        results = (
            self.vector_store.collection.query(

                query_embeddings=[
                    query_embedding.tolist()
                ],

                n_results=number_of_results,

                where=where_filter

            )
        )

        # ----------------------------------------------------
        # 5. Extract results
        # ----------------------------------------------------

        retrieved_chunks = []

        ids = results["ids"][0]

        documents = results["documents"][0]

        metadatas = results["metadatas"][0]

        distances = results["distances"][0]

        # ----------------------------------------------------
        # 6. Normalize result structure
        # ----------------------------------------------------

        for i in range(len(ids)):

            metadata = (
                metadatas[i]
                or {}
            )

            retrieved_chunks.append({

                "chunk_id": ids[i],

                "paper_id": metadata.get(
                    "paper_id",
                    ""
                ),

                "paper_title": metadata.get(
                    "paper_title",
                    ""
                ),

                "text": documents[i],

                "section": metadata.get(
                    "section",
                    ""
                ),

                "page_start": metadata.get(
                    "page_start",
                    0
                ),

                "page_end": metadata.get(
                    "page_end",
                    0
                ),

                "word_count": metadata.get(
                    "word_count",
                    0
                ),

                "distance": distances[i]

            })

        return retrieved_chunks
