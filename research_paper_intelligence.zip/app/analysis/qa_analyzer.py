import re

from app.analysis.task_router import TaskRouter
from app.analysis.claim_grounder import ClaimGrounder
from app.analysis.claim_relevance_validator import ClaimRelevanceValidator
from app.analysis.answer_synthesizer import GroundedAnswerSynthesizer
from app.analysis.citation_generator import CitationGenerator
from app.analysis.hallucination_detector import HallucinationDetector
from app.analysis.confidence_scorer import ConfidenceScorer

from app.retrieval.bm25_retriever import BM25Retriever


class QAAnalyzer:
    _TASK_FILTERED_TASKS = {
        "methodology", "datasets", "models", "results",
        "limitations", "future_work", "literature_review",
    }

    """
    Complete QA orchestration layer.
    Pipeline:
        Question -> TaskRouter -> TaskSpecificRetriever -> Evidence
        -> ClaimGrounder -> Grounded Claims -> ClaimRelevanceValidator
        -> Relevant Grounded Claims -> GroundedAnswerSynthesizer
        -> Grounded Answer -> HallucinationDetector
        -> Support / Hallucination Check -> CitationGenerator
        -> Claim Citations + Sources
    """

    def __init__(
        self,
        task_retriever,
        claim_grounder=None,
        claim_relevance_validator=None,
        task_router=None,
        answer_synthesizer=None,
        citation_generator=None,
        hallucination_detector=None,
        confidence_scorer=None,
    ):
        self.task_retriever = task_retriever
        self.claim_grounder = (
            claim_grounder if claim_grounder is not None else ClaimGrounder()
        )
        self.claim_relevance_validator = (
            claim_relevance_validator
            if claim_relevance_validator is not None
            else ClaimRelevanceValidator()
        )
        self.task_router = (
            task_router if task_router is not None else TaskRouter()
        )
        self.answer_synthesizer = (
            answer_synthesizer
            if answer_synthesizer is not None
            else GroundedAnswerSynthesizer()
        )
        self.citation_generator = (
            citation_generator
            if citation_generator is not None
            else CitationGenerator()
        )
        self.hallucination_detector = (
            hallucination_detector
            if hallucination_detector is not None
            else HallucinationDetector()
        )
        self.confidence_scorer = (
            confidence_scorer
            if confidence_scorer is not None
            else ConfidenceScorer()
        )

    # ============================================================
    # PUBLIC ANSWER METHOD
    # ============================================================
    def answer(self, question, task=None):
        question = str(question or "").strip()

        if not question:
            return {
                "answer": "Please provide a question.",
                "task": task if task else "question_answering",
                "claims": [],
                "evidence": [],
                "task_scores": {},
                "hallucination": {
                    "supported": False,
                    "hallucination_detected": False,
                    "support_score": 0.0,
                    "claims": [],
                },
                "citations": [],
                "sources": [],
                "confidence": {"score": 0.0, "label": "LOW"},
            }

        # ========================================================
        # 1. TASK DETECTION
        # ========================================================
        if task is None:
            task, task_scores = self._detect_task(question)
        else:
            task = str(task).lower().strip()
            task_scores = {task: 1}

        print(f"Detected task: {task}")

        # ========================================================
        # 2. RETRIEVAL
        # ========================================================
        evidence = self._retrieve(question, task)

        if not evidence:
            return {
                "answer": (
                    "The paper does not provide "
                    "sufficient evidence to answer "
                    "this question."
                ),
                "task": task,
                "claims": [],
                "evidence": [],
                "task_scores": task_scores,
                "hallucination": {
                    "supported": False,
                    "hallucination_detected": False,
                    "support_score": 0.0,
                    "claims": [],
                },
                "citations": [],
                "sources": [],
                "confidence": {"score": 0.0, "label": "LOW"},
            }

        # ========================================================
        # 3. DISPLAY EVIDENCE
        # ========================================================
        self._print_evidence(evidence, task)

        # ========================================================
        # 4. CLAIM GROUNDING
        # ========================================================
        print("\nGrounding retrieved evidence...")
        grounded = self.claim_grounder.ground(
            evidence=evidence, task=task, instruction=question
        )
        grounded_claims = list(getattr(grounded, "claims", []))
        print("Grounded claims:", len(grounded_claims))

        if not grounded_claims:
            return {
                "answer": (
                    "The retrieved evidence was relevant, "
                    "but no sufficiently grounded claims "
                    "could be extracted."
                ),
                "task": task,
                "claims": [],
                "evidence": self._build_evidence_output(evidence),
                "task_scores": task_scores,
                "hallucination": {
                    "supported": False,
                    "hallucination_detected": False,
                    "support_score": 0.0,
                    "claims": [],
                },
                "citations": [],
                "sources": [],
                "confidence": {"score": 0.0, "label": "LOW"},
            }

        # ========================================================
        # 5. QUESTION RELEVANCE
        # ========================================================
        print("\nRanking grounded claims by question relevance...")

        try:
            ranked_claims = self.claim_relevance_validator.filter_claims(
                question=question,
                claims=grounded_claims,
                task=task,
                max_claims=max(12, len(grounded_claims)),
            )
        except TypeError:
            ranked_claims = self.claim_relevance_validator.filter_claims(
                question=question,
                claims=grounded_claims,
                max_claims=max(12, len(grounded_claims)),
            )
        except Exception as exc:
            print("Claim relevance ranking failed:", exc)
            ranked_claims = list(grounded_claims)

        if not ranked_claims:
            ranked_claims = list(grounded_claims)

        relevant_claims = self._select_relevant_claims(
            question=question,
            task=task,
            ranked_claims=ranked_claims,
            grounded_claims=grounded_claims,
            evidence=evidence,
        )

        print("Relevant grounded claims:", len(relevant_claims))
        print(
            "Papers represented in final claims:",
            sorted(self._claim_paper_ids(relevant_claims, evidence)),
        )

        # ========================================================
        # 6. GROUNDED ANSWER SYNTHESIS
        # ========================================================
        print("\nSynthesizing grounded answer...")
        synthesis = self.answer_synthesizer.synthesize(
            question=question,
            task=task,
            grounded_claims=relevant_claims,
            evidence=evidence,
        )
        answer_text = str(synthesis.get("answer", "")).strip()

        if not answer_text:
            answer_text = (
                "The available evidence does not "
                "contain enough grounded information "
                "to answer this question."
            )

        print("Answer synthesis complete.")

        # ========================================================
        # 7. HALLUCINATION / SUPPORT DETECTION
        # ========================================================
        print("\nChecking answer for hallucination...")
        try:
            hallucination_result = self.hallucination_detector.verify(
                answer=self._build_claim_verification_text(relevant_claims),
                evidence=evidence,
            )
        except Exception as exc:
            print("Hallucination detection failed.")
            print("Reason:", exc)
            hallucination_result = {
                "answer": answer_text,
                "supported": False,
                "hallucination_detected": False,
                "support_score": 0.0,
                "claims": [],
            }

        print("Hallucination check complete.")
        print("Supported:", hallucination_result.get("supported", False))
        print(
            "Hallucination detected:",
            hallucination_result.get("hallucination_detected", False),
        )
        print(
            "Support score:", hallucination_result.get("support_score", 0.0)
        )

        # ========================================================
        # 8. CITATION GENERATION
        # ========================================================
        print("\nGenerating citations and source attribution...")
        try:
            citation_result = self.citation_generator.generate(
                claims=relevant_claims, evidence=evidence
            )
        except Exception as exc:
            print("Citation generation failed.")
            print("Reason:", exc)
            citation_result = {
                "claim_citations": [],
                "sources": [],
                "source_count": 0,
            }

        claim_citations = citation_result.get("claim_citations", [])

        # Never expose placeholder titles such as "paper2" as if they were
        # bibliographic titles. If ingestion did not recover a real title,
        # leave it blank and let the UI identify the source by paper ID.
        claim_citations = self._sanitize_citation_titles(claim_citations)

        sources = citation_result.get("sources", [])

        print("Citation generation complete.")
        print("Claim citation groups:", len(claim_citations))
        print("Unique sources:", len(sources))

        # ========================================================
        # 9. CONFIDENCE / RELIABILITY SCORING
        # ========================================================
        print("\nCalculating answer confidence...")
        try:
            confidence_result = self.confidence_scorer.score(
                claims=relevant_claims,
                evidence=evidence,
                citations=claim_citations,
                hallucination=hallucination_result,
            )
        except Exception as exc:
            print("Confidence scoring failed.")
            print("Reason:", exc)
            confidence_result = {
                "score": 0.0,
                "label": "LOW",
                "reason": "Confidence scoring failed.",
            }

        if not isinstance(confidence_result, dict):
            confidence_result = {
                "score": 0.0,
                "label": "LOW",
                "reason": "Invalid confidence scorer output.",
            }

        # --------------------------------------------------------
        # Conservative confidence calibration. Confidence is a
        # reliability indicator, not a probability of factual
        # correctness. Penalize cases where the pipeline has weak
        # task evidence, missing citations, unsupported claims, or
        # incomplete multi-paper coverage.
        # --------------------------------------------------------
        comparison = self._is_comparison_question(question)
        confidence_result = self._calibrate_confidence(
            confidence_result=confidence_result,
            task=task,
            claims=relevant_claims,
            citations=claim_citations,
            hallucination=hallucination_result,
            evidence=evidence,
            comparison=comparison,
        )

        # --------------------------------------------------------
        # Comparison coverage guard: penalize a comparison answer
        # that didn't get grounded claims from every available
        # paper. This must run AFTER the general calibration above
        # and must be the LAST adjustment made to confidence_result
        # -- a duplicate _calibrate_confidence() call used to run
        # again after this block and silently overwrite the
        # coverage penalty computed here with a fresh, uninformed
        # recalculation. That duplicate call has been removed.
        # --------------------------------------------------------
        if comparison:
            available_paper_ids = self._get_available_paper_ids()
            final_paper_ids = self._claim_paper_ids(relevant_claims, evidence)

            if available_paper_ids:
                paper_coverage = (
                    len(final_paper_ids & available_paper_ids)
                    / len(available_paper_ids)
                )
            else:
                paper_coverage = 0.0

            base_score = float(confidence_result.get("score", 0.0))
            adjusted_score = base_score * (0.50 + 0.50 * paper_coverage)

            if paper_coverage < 1.0:
                adjusted_score = min(adjusted_score, 79.99)

            confidence_result["score"] = round(
                max(0.0, min(100.0, adjusted_score)), 2
            )
            confidence_result["paper_coverage"] = round(
                paper_coverage * 100.0, 2
            )
            confidence_result.setdefault("components", {})
            confidence_result["components"]["paper_coverage"] = round(
                paper_coverage * 100.0, 2
            )

            if adjusted_score >= 85.0:
                confidence_result["label"] = "HIGH"
            elif adjusted_score >= 60.0:
                confidence_result["label"] = "MEDIUM"
            else:
                confidence_result["label"] = "LOW"

            if paper_coverage < 1.0:
                confidence_result["explanation"] = (
                    "The answer is grounded, but not all available "
                    "papers contributed grounded claims to the "
                    "comparison."
                )

        print("Confidence scoring complete.")
        print("Confidence score:", confidence_result.get("score", 0.0))
        print("Confidence level:", confidence_result.get("label", "LOW"))

        # ========================================================
        # 10. FINAL CONTRACT
        # ========================================================
        return {
            "answer": answer_text,
            "task": task,
            "claims": relevant_claims,
            "evidence": self._build_evidence_output(evidence),
            "task_scores": task_scores,
            "hallucination": hallucination_result,
            "citations": claim_citations,
            "sources": sources,
            "confidence": confidence_result,
        }

    # ============================================================
    # COMPARISON / PAPER-AWARE HELPERS
    # ============================================================
    @staticmethod
    def _is_comparison_question(question):
        q = str(question or "").lower().strip()
        phrases = [
            "compare", "comparison", "comparative",
            "differences between", "difference between",
            "similarities between", "similarity between",
            "similarities and differences", "across papers",
            "across studies", "between papers", "between studies",
            "all papers", "all the papers", "each paper",
            "both papers", "both studies",
        ]
        return any(p in q for p in phrases)

    def _get_available_chunks(self):
        candidates = [
            self.task_retriever,
            getattr(self.task_retriever, "hybrid_retriever", None),
        ]
        hybrid = getattr(self.task_retriever, "hybrid_retriever", None)
        if hybrid is not None:
            candidates.extend([
                getattr(hybrid, "bm25_retriever", None),
                getattr(hybrid, "vector_retriever", None),
            ])
        for candidate in candidates:
            chunks = getattr(candidate, "chunks", None)
            if chunks:
                return list(chunks)
        return []

    def _get_available_paper_ids(self):
        result = set()
        for chunk in self._get_available_chunks():
            paper_id = (
                chunk.get("paper_id")
                if isinstance(chunk, dict)
                else getattr(chunk, "paper_id", None)
            )
            if paper_id:
                result.add(str(paper_id))
        return result

    @staticmethod
    def _claim_paper_ids(claims, evidence):
        evidence_map = {}
        for item in evidence:
            if isinstance(item, dict):
                chunk_id = item.get("chunk_id")
                paper_id = item.get("paper_id")
            else:
                chunk_id = getattr(item, "chunk_id", None)
                paper_id = getattr(item, "paper_id", None)
            if chunk_id and paper_id:
                evidence_map[str(chunk_id)] = str(paper_id)

        result = set()
        for claim in claims:
            if isinstance(claim, dict):
                paper_id = claim.get("paper_id")
                evidence_ids = claim.get("evidence_ids", [])
            else:
                paper_id = getattr(claim, "paper_id", None)
                evidence_ids = getattr(claim, "evidence_ids", [])

            if paper_id:
                result.add(str(paper_id))
                continue

            for evidence_id in evidence_ids or []:
                resolved = evidence_map.get(str(evidence_id))
                if resolved:
                    result.add(resolved)
                    break

        return result

    @staticmethod
    def _build_claim_verification_text(claims):
        texts = []
        for claim in claims:
            if isinstance(claim, dict):
                text = claim.get("claim") or claim.get("text") or ""
            else:
                text = (
                    getattr(claim, "claim", None)
                    or getattr(claim, "text", None)
                    or ""
                )
            text = str(text).strip()
            if text:
                texts.append(text)
        return " ".join(texts)

    # ============================================================
    # RETRIEVAL
    # ============================================================
    def _retrieve(self, question, task):
        if self._is_comparison_question(question):
            comparison_results = self._retrieve_per_paper(question, task)
            if comparison_results:
                return comparison_results

        retriever = self.task_retriever

        for method_name in ("search", "retrieve", "run"):
            method = getattr(retriever, method_name, None)
            if method is None:
                continue

            try:
                results = method(query=question, task=task, top_k=8)
            except TypeError:
                try:
                    results = method(question, task, 8)
                except Exception as exc:
                    print(f"Task retriever {method_name} failed:", exc)
                    continue
            except Exception as exc:
                print(f"Task retriever {method_name} failed:", exc)
                continue

            if results:
                return self._filter_task_evidence(results, task)

        raise AttributeError(
            "TaskSpecificRetriever must provide "
            "search(), retrieve(), or run()."
        )

    def _retrieve_per_paper(self, question, task):
        all_chunks = self._get_available_chunks()
        if not all_chunks:
            return []

        grouped = {}
        for chunk in all_chunks:
            paper_id = (
                chunk.get("paper_id")
                if isinstance(chunk, dict)
                else getattr(chunk, "paper_id", None)
            )
            if paper_id:
                grouped.setdefault(str(paper_id), []).append(chunk)

        if not grouped:
            return []

        print("Comparison query detected: retrieving evidence per paper.")
        print("Papers available for comparison:", sorted(grouped.keys()))

        merged = {}
        paper_limit = 3 if len(grouped) <= 5 else 2
        reranker = getattr(self.task_retriever, "reranker", None)

        for paper_id, chunks in grouped.items():
            try:
                local_bm25 = BM25Retriever(chunks)

                task_name = str(task or "").lower().strip()
                if task_name == "limitations":
                    local_query = (
                        f"{question} {task_name} "
                        "limitations weaknesses constraints "
                        "generalizability sample sampling self-reported "
                        "scenario ecological validity actual interaction "
                        "real usage future research methodology "
                        "research design participants data collection "
                        "measurement analysis"
                    )
                else:
                    local_query = (
                        f"{question} {task} methodology research design "
                        "participants sampling data collection procedure "
                        "measurement analysis"
                    )

                local_results = local_bm25.search(
                    local_query, top_k=max(5, paper_limit + 2)
                )

                if hasattr(self.task_retriever, "_apply_task_score"):
                    local_results = self.task_retriever._apply_task_score(
                        local_results, task
                    )

                if reranker is not None and local_results:
                    try:
                        local_results = reranker.rerank(
                            query=question,
                            results=local_results,
                            top_k=len(local_results),
                        )
                    except Exception:
                        pass

                local_results = self._filter_task_evidence(
                    local_results, task
                )

                selected = local_results[:paper_limit]

                for item in selected:
                    chunk_id = item.get("chunk_id")
                    if chunk_id:
                        item = dict(item)
                        item["paper_id"] = item.get("paper_id") or paper_id
                        merged[chunk_id] = item

                print(f"  {paper_id}: {len(selected)} evidence chunk(s)")

            except Exception as exc:
                print(f"  {paper_id}: per-paper retrieval failed: {exc}")

        # Supplement with the normal hybrid retrieval pool.
        try:
            global_results = self.task_retriever.search(
                query=question, task=task, top_k=min(10, len(all_chunks))
            )
            global_results = self._filter_task_evidence(
                global_results, task
            )
            for item in global_results:
                chunk_id = item.get("chunk_id")
                if chunk_id and chunk_id not in merged:
                    merged[chunk_id] = item
        except Exception:
            pass

        results = list(merged.values())
        results.sort(
            key=lambda x: x.get(
                "combined_score", x.get("reranker_score", x.get("score", 0.0))
            ),
            reverse=True,
        )

        # Re-insert the strongest item from every paper after sorting.
        covered = []
        used = set()
        for paper_id in grouped:
            candidates = [
                item for item in results
                if str(item.get("paper_id", "")) == str(paper_id)
            ]
            if candidates:
                best = candidates[0]
                covered.append(best)
                used.add(best.get("chunk_id"))

        max_evidence = max(20, len(grouped) * paper_limit)
        for item in results:
            if len(covered) >= max_evidence:
                break
            if item.get("chunk_id") in used:
                continue
            covered.append(item)
            used.add(item.get("chunk_id"))

        return covered

    @staticmethod
    def _filter_claims_for_task(claims, task):
        """Filter grounded claims by the detected research task.

        Claim grounding proves that a claim is supported by retrieved
        evidence; this additional check prevents a supported but unrelated
        claim from representing a paper in task-specific QA.
        """
        if not claims:
            return []

        task_name = str(task or "").lower().strip()
        keywords = {
            "methodology": (
                "method", "methodology", "research design",
                "experimental design", "procedure", "participant",
                "participants", "sample", "sampling", "data collection",
                "questionnaire", "survey", "interview", "measurement",
                "measure", "experiment", "analysis",
            ),
            "datasets": (
                "dataset", "datasets", "data", "sample", "participants",
                "respondents", "data source", "data collection",
            ),
            "models": (
                "model", "models", "algorithm", "algorithms",
                "architecture", "framework", "classifier", "embedding",
                "transformer", "neural network",
            ),
            "results": (
                "result", "results", "finding", "findings", "effect",
                "significant", "hypothesis", "hypotheses", "outcome",
                "performance", "supported",
            ),
            "limitations": (
                "limitation", "limitations", "weakness", "weaknesses",
                "constraint", "constraints", "generalizability",
                "generalisation", "generalization", "self-reported",
                "ecological validity", "did not", "didn't", "not account",
                "relied exclusively", "limited", "lack of",
            ),
            "future_work": (
                "future research", "future work", "future studies",
                "further research", "research directions", "next research",
                "should", "could", "recommended",
            ),
            "literature_review": (
                "literature", "related work", "previous research",
                "prior research", "prior studies", "previous studies",
                "theoretical background",
            ),
        }

        task_keywords = keywords.get(task_name)
        if not task_keywords:
            return list(claims)

        filtered = []
        for claim in claims:
            if isinstance(claim, dict):
                text = claim.get("claim") or claim.get("text") or ""
            else:
                text = (
                    getattr(claim, "claim", None)
                    or getattr(claim, "text", None)
                    or ""
                )
            text = str(text).lower().strip()
            if any(keyword in text for keyword in task_keywords):
                filtered.append(claim)

        return filtered or list(claims)

    def _filter_task_evidence(self, results, task):
        if not results:
            return []

        if str(task or "").lower().strip() != "methodology":
            return list(results)

        filtered = []
        for item in results:
            section = str(item.get("section", "")).lower().strip()
            text = str(item.get("text", "")).lower()

            # --------------------------------------------------------
            # "introduction" is excluded alongside the other sections
            # below so the evidence list shown to the user stays
            # consistent with claim_grounder.py's _methodology_claims,
            # which already refuses to build claims from introduction
            # sections (they routinely describe gaps in OTHER studies'
            # methodology using the same vocabulary this task looks
            # for). Previously the evidence display still admitted
            # these chunks even though no claim was ever built from
            # them -- confusing to read, even though it didn't affect
            # the final answer.
            # --------------------------------------------------------
            if any(
                term in section
                for term in (
                    "reference", "appendix", "future",
                    "limitation", "general discussion",
                    "results and discussion", "introduction",
                )
            ):
                continue

            if section:
                preferred = any(
                    term in section
                    for term in (
                        "method", "design", "participant",
                        "data collection", "procedure",
                        "measurement", "measure", "sample",
                    )
                )
                if not preferred:
                    method_terms = sum(
                        term in text
                        for term in (
                            "participants", "sample", "survey",
                            "questionnaire", "interview",
                            "experimental", "data were collected",
                            "data was collected", "randomly assigned",
                            "likert", "sampling",
                        )
                    )
                    if method_terms < 2:
                        continue

            filtered.append(item)

        return filtered or list(results)

    # ============================================================
    # PRINT EVIDENCE
    # ============================================================
    @staticmethod
    def _print_evidence(evidence, task):
        print("\n" + "=" * 80)
        print("EVIDENCE SENT TO CLAIM GROUNDER")
        print("=" * 80)
        print(f"Task: {task}")
        print(f"Evidence count: {len(evidence)}")

        for index, item in enumerate(evidence, start=1):
            print(f"\nEVIDENCE {index}")
            print("-" * 80)
            print("Chunk:", item.get("chunk_id", ""))
            print("Section:", item.get("section", ""))
            print(
                "Pages:",
                item.get("page_start", 0),
                "-",
                item.get("page_end", 0),
            )
            print("Task score:", item.get("task_score", 0))
            print("Reranker score:", item.get("reranker_score", 0))
            print("Combined score:", item.get("combined_score", 0))
            print("Text:")
            print(item.get("text", ""))

    # ============================================================
    # EVIDENCE OUTPUT
    # ============================================================
    @staticmethod
    def _build_evidence_output(evidence):
        output = []
        for item in evidence:
            output.append({
                "paper_id": item.get("paper_id", ""),
                "paper_title": item.get("paper_title", ""),
                "page_start": item.get("page_start", 0),
                "page_end": item.get("page_end", 0),
                "section": item.get("section", ""),
                "chunk_id": item.get("chunk_id", ""),
                "text": item.get("text", ""),
                "task_score": item.get("task_score", 0),
                "rrf_score": item.get("rrf_score", 0.0),
                "reranker_score": item.get("reranker_score", 0.0),
                "combined_score": item.get("combined_score", 0.0),
            })
        return output

    # ============================================================
    # FINAL TASK ROUTING / CLAIM SELECTION
    # ============================================================
    @staticmethod
    def _normalize_task(task):
        aliases = {
            "contribution": "contributions",
            "main_contribution": "contributions",
            "statistical": "statistical_analysis",
            "statistics": "statistical_analysis",
            "analyses": "statistical_analysis",
            "analysis": "statistical_analysis",
            "variables": "variables",
            "constructs": "variables",
            "theory": "theoretical_framework",
            "framework": "theoretical_framework",
            "comparison": "comparison",
        }
        value = str(task or "question_answering").lower().strip()
        return aliases.get(value, value)

    @classmethod
    def _heuristic_task(cls, question):
        q = " ".join(str(question or "").lower().split())

        # Comparison is a modifier, not a content task. Determine the
        # requested content first so retrieval/grounding remains task-aware.
        _ = cls._is_comparison_question(q)

        patterns = [
            ("limitations", (
                "limitation", "limitations", "weakness", "weaknesses",
                "constraint", "constraints", "drawbacks", "shortcomings",
                "what are the limitations", "what limitations",
            )),
            ("future_work", (
                "future research", "future work", "future studies",
                "research directions", "further research", "what should be",
                "what could be explored", "recommendations for future",
            )),
            ("contributions", (
                "contribution", "contributions", "novel contribution",
                "theoretical contribution", "practical contribution",
                "main contribution", "key contribution",
                "what does the paper add",
            )),
            ("methodology", (
                "methodology", "methodologies", "method", "methods",
                "how was the study conducted",
                "how were the studies conducted",
                "research design", "experimental design", "study design",
                "procedure", "data collection", "sampling approach",
            )),
            ("datasets", (
                "dataset", "datasets", "sample size", "participants",
                "respondents", "sample", "who participated", "data source",
            )),
            ("statistical_analysis", (
                "statistical analysis", "statistical analyses",
                "statistical test", "statistical tests", "what analyses",
                "what analysis", "which tests", "regression", "anova",
                "pca", "mediation analysis", "moderation analysis",
                "hypothesis testing",
            )),
            ("variables", (
                "variables", "constructs", "factors", "key variables",
                "independent variable", "dependent variable", "mediator",
                "moderator", "what variables", "which variables",
            )),
            ("models", (
                "models", "model", "algorithm", "algorithms",
                "architecture", "framework", "classifier",
                "embedding model", "transformer",
            )),
            ("results", (
                "main findings", "key findings", "findings", "results",
                "main result", "outcomes", "what did the study find",
                "what did the studies find", "effects", "effect of",
                "hypotheses supported",
            )),
            ("literature_review", (
                "literature review", "related work", "previous research",
                "prior research", "prior studies", "theoretical background",
                "what does the literature say",
            )),
        ]

        scored = []
        for task, terms in patterns:
            score = 0
            for term in terms:
                if term in q:
                    score += 3 if " " in term else 2
            scored.append((score, task))

        scored.sort(reverse=True)
        best_score, best_task = scored[0]

        if best_score <= 0:
            best_task = "question_answering"

        return best_task, {task: score for score, task in scored if score > 0}

    def _detect_task(self, question):
        # Deterministic high-precision routing comes first. This prevents a
        # generic TaskRouter label such as question_answering from
        # overriding obvious research intents like contributions or
        # statistical analyses.
        task, scores = self._heuristic_task(question)
        if task != "question_answering":
            if self._is_comparison_question(question):
                print("Comparison modifier detected; using task:", task)
            return task, scores

        try:
            result = self.task_router.route(question)
            if isinstance(result, tuple) and len(result) >= 2:
                routed_task, routed_scores = result[0], result[1]
                routed_task = self._normalize_task(routed_task)
                return routed_task, routed_scores or scores
            if isinstance(result, dict):
                routed_task = self._normalize_task(result.get("task"))
                return routed_task, result.get("task_scores", scores)
        except Exception as exc:
            print("TaskRouter fallback:", exc)

        return "question_answering", scores

    @staticmethod
    def _claim_text_for_selection(claim):
        if isinstance(claim, dict):
            return str(claim.get("claim") or claim.get("text") or "").strip()
        return str(
            getattr(claim, "claim", None)
            or getattr(claim, "text", None)
            or ""
        ).strip()

    @classmethod
    def _claim_paper_id_for_selection(cls, claim, evidence):
        if isinstance(claim, dict):
            direct = claim.get("paper_id")
            evidence_ids = claim.get("evidence_ids", []) or []
            citations = claim.get("citations", []) or []
        else:
            direct = getattr(claim, "paper_id", None)
            evidence_ids = getattr(claim, "evidence_ids", []) or []
            citations = getattr(claim, "citations", []) or []

        if direct:
            return str(direct)

        for c in citations:
            value = (
                c.get("paper_id")
                if isinstance(c, dict)
                else getattr(c, "paper_id", None)
            )
            if value:
                return str(value)

        mapping = {}
        for item in evidence:
            if isinstance(item, dict):
                cid, pid = item.get("chunk_id"), item.get("paper_id")
            else:
                cid = getattr(item, "chunk_id", None)
                pid = getattr(item, "paper_id", None)
            if cid and pid:
                mapping[str(cid)] = str(pid)

        for eid in evidence_ids:
            if str(eid) in mapping:
                return mapping[str(eid)]
            if "_chunk_" in str(eid):
                return str(eid).split("_chunk_", 1)[0]

        return None

    @classmethod
    def _select_relevant_claims(
        cls, question, task, ranked_claims, grounded_claims, evidence
    ):
        task = cls._normalize_task(task)
        comparison = cls._is_comparison_question(question)

        # Strict semantic/task gates. They prevent a supported but
        # irrelevant sentence (e.g. a questionnaire item) from reaching
        # synthesis.
        positive = {
            "methodology": (
                "method", "design", "procedure", "participants", "sample",
                "sampling", "data collection", "questionnaire", "survey",
                "interview", "measurement", "experiment", "analysis",
            ),
            "datasets": (
                "sample", "participants", "respondents", "dataset",
                "data source", "responses", "retained", "collected",
            ),
            "models": (
                "model", "algorithm", "architecture", "framework",
                "classifier", "embedding", "transformer",
            ),
            "results": (
                "finding", "findings", "result", "results", "effect",
                "significant", "supported", "β", "p <",
                "confidence interval", "mediation", "moderation",
                "regression", "anova",
            ),
            "limitations": (
                "limitation", "limitations", "weakness", "constraint",
                "generalizability", "generalisation", "self-reported",
                "ecological validity", "scenario-based",
                "did not account", "not directly measured",
                "not empirically tested", "convenience sampling",
                "snowball", "single country", "imagined",
            ),
            "future_work": (
                "future research", "future work", "future studies",
                "further research", "research directions", "should",
                "could", "recommend", "longitudinal", "field experiment",
                "actual interaction", "working vto",
            ),
            "literature_review": (
                "literature", "previous research", "prior research",
                "prior studies", "related work", "theoretical background",
            ),
            "contributions": (
                "contribution", "contributions", "theoretical",
                "practical", "managerial", "novel", "extends", "advances",
                "implication", "implications", "adds to",
            ),
            "statistical_analysis": (
                "pca", "principal component", "regression", "anova",
                "mediation", "moderation", "bootstrap",
                "confidence interval", "hypothesis test",
                "structural equation", "sem", "process macro", "variance",
                "r²", "r2", "β", "beta",
            ),
            "variables": (
                "variable", "variables", "construct", "constructs",
                "predictor", "mediator", "moderator", "dependent",
                "independent", "factor", "perceived usefulness",
                "attitude", "willingness",
            ),
        }
        negative = {
            "results": (
                "future research", "future work", "limitation",
                "questionnaire item", "i would recommend",
                "ethical statement",
            ),
            "limitations": (
                "future research", "future work", "i would recommend",
                "ethical statement", "informed consent", "apc",
                "generative ai",
            ),
            "future_work": (
                "i would recommend", "i would",
                "recommend vto to others", "ethical statement",
                "informed consent", "apc", "generative ai", "references",
                "bibliography",
            ),
            "contributions": (
                "pca was", "principal component analysis was",
                "questionnaire", "participants were", "sample was",
                "data were collected", "statistical analysis",
            ),
            "statistical_analysis": (
                "future research", "limitation", "i would recommend",
                "ethical statement",
            ),
            "methodology": (
                "future research", "limitation", "results and discussion",
                "references", "bibliography",
            ),
        }

        candidates = []
        seen = set()
        for claim in list(ranked_claims) + list(grounded_claims):
            text = cls._claim_text_for_selection(claim)
            key = " ".join(text.lower().split())
            if not key or key in seen:
                continue
            seen.add(key)
            low = key
            if cls._looks_like_noise(low):
                continue

            score = 0.0
            terms = positive.get(task, ())
            for term in terms:
                if term in low:
                    score += 2.0
            for term in negative.get(task, ()):
                if term in low:
                    score -= 5.0

            # Claims that directly contain the question's important words
            # get a small additional boost without replacing the
            # cross-encoder rank.
            q_tokens = set(re.findall(r"[a-z0-9]{4,}", str(question).lower()))
            c_tokens = set(re.findall(r"[a-z0-9]{4,}", low))
            if q_tokens:
                score += 1.5 * (len(q_tokens & c_tokens) / max(1, len(q_tokens)))

            if score <= -1.0 and task in positive:
                continue
            candidates.append((score, claim))

        candidates.sort(key=lambda x: x[0], reverse=True)
        ordered = [c for _, c in candidates]

        # For comparisons, guarantee coverage before filling globally.
        max_final = 12 if comparison else 10
        if comparison:
            by_paper = {}
            for claim in ordered:
                pid = (
                    cls._claim_paper_id_for_selection(claim, evidence)
                    or "__unknown__"
                )
                by_paper.setdefault(pid, []).append(claim)
            selected = []
            for pid in sorted(by_paper):
                if by_paper[pid]:
                    selected.append(by_paper[pid][0])
            for claim in ordered:
                if len(selected) >= max_final:
                    break
                if claim not in selected:
                    selected.append(claim)
            ordered = selected

        # Do not silently reintroduce all grounded claims for strict tasks.
        # If the strict gate found nothing, return the best semantic
        # candidates only for genuinely open-ended QA.
        if not ordered and task not in cls._TASK_FILTERED_TASKS and grounded_claims:
            ordered = list(grounded_claims)

        return ordered[:max_final]

    @staticmethod
    def _looks_like_noise(text):
        t = " ".join(str(text or "").lower().split())
        if not t:
            return True
        if re.search(r"\b(?:references|bibliography|appendix)\b", t):
            return True
        if re.search(r"\b20\d{2}\b", t) and "et al." in t and len(t.split()) < 35:
            return True
        noise_phrases = (
            "article processing charges",
            "declaration of generative ai",
            "generative ai and ai-assisted",
            "personally identifiable information was not gathered",
            "institutional ethics committee",
            "informed consent",
            "i would recommend",
            "i would recommend vto",
            "would recommend vto to others",
        )
        return any(p in t for p in noise_phrases)

    @staticmethod
    def _sanitize_citation_titles(claim_citations):
        clean = []
        for group in claim_citations or []:
            if not isinstance(group, dict):
                continue
            item = dict(group)
            citations = []
            for citation in item.get("citations", []) or []:
                if not isinstance(citation, dict):
                    continue
                c = dict(citation)
                pid = str(c.get("paper_id", "")).strip().lower()
                title = str(c.get("paper_title", "")).strip()
                if title.lower() in {
                    pid, f"{pid}.pdf", "paper1", "paper2",
                    "paper 1", "paper 2",
                }:
                    c["paper_title"] = ""
                citations.append(c)
            item["citations"] = citations
            clean.append(item)
        return clean

    @staticmethod
    def _calibrate_confidence(
        confidence_result, task, claims, citations, hallucination,
        evidence, comparison=False,
    ):
        if not isinstance(confidence_result, dict):
            confidence_result = {"score": 0.0, "label": "LOW", "components": {}}
        score = float(confidence_result.get("score", 0.0) or 0.0)
        components = dict(confidence_result.get("components", {}) or {})

        citation_coverage = 0.0
        if claims:
            cited = sum(
                1 for c in citations or []
                if isinstance(c, dict) and c.get("citations")
            )
            citation_coverage = cited / len(claims)

        if not claims:
            score = min(score, 20.0)
        if citation_coverage < 1.0:
            score = min(score, 69.0)
        if hallucination.get("hallucination_detected", False):
            score = min(score, 49.0)
        if not hallucination.get("supported", False) and claims:
            score = min(score, 49.0)

        if comparison:
            paper_ids = set()
            for c in claims:
                pid = QAAnalyzer._claim_paper_ids([c], evidence)
                paper_ids.update(pid)
            available = QAAnalyzer._get_available_paper_ids_static(evidence)
            if available and len(paper_ids & available) < len(available):
                score = min(score, 59.0)

        score = round(max(0.0, min(100.0, score)), 2)
        if score >= 85:
            label = "HIGH"
        elif score >= 60:
            label = "MEDIUM"
        else:
            label = "LOW"

        confidence_result["score"] = score
        confidence_result["label"] = label
        components["citation_coverage"] = round(citation_coverage * 100, 2)
        confidence_result["components"] = components
        return confidence_result

    @staticmethod
    def _get_available_paper_ids_static(evidence):
        result = set()
        for item in evidence or []:
            if isinstance(item, dict):
                pid = item.get("paper_id")
            else:
                pid = getattr(item, "paper_id", None)
            if pid:
                result.add(str(pid))
        return result
