import re
from collections import defaultdict
from typing import Any, Dict


class GroundedAnswerSynthesizer:
    """Turn grounded claims into clean, research-style answers.

    This component is deliberately extractive/conservative: it does not invent
    facts, numbers, paper characteristics, or citations. It organizes the
    already-grounded claims and removes common PDF-extraction artefacts.
    """

    def __init__(self, max_claims=12, max_evidence=20):
        self.max_claims = int(max_claims)
        self.max_evidence = int(max_evidence)

    def synthesize(self, question: str, task: str, grounded_claims=None, evidence=None) -> Dict[str, Any]:
        question = str(question or "").strip()
        task = str(task or "question_answering").lower().strip()
        claims = list(grounded_claims or [])[: self.max_claims]
        evidence = list(evidence or [])

        cleaned = []
        seen = set()
        for claim in claims:
            text = self._clean_text(self._claim_text(claim))
            if not text or self._is_noise(text):
                continue
            key = re.sub(r"\W+", " ", text.lower()).strip()
            if key in seen:
                continue
            seen.add(key)
            cleaned.append((claim, text))

        if not cleaned:
            answer = "The available grounded evidence is insufficient to answer this question reliably."
        elif self._is_comparison_question(question):
            answer = self._compose_comparison(question, task, cleaned)
        else:
            answer = self._compose_standard(question, task, cleaned)

        return {
            "answer": answer.strip(),
            "task": task,
            "claim_count": len(cleaned),
            "evidence_count": min(len(evidence), self.max_evidence),
        }

    def _compose_standard(self, question, task, cleaned):
        openings = {
            "methodology": "The methodology reported in the papers is summarized below.",
            "datasets": "The papers report the following sample, participant, and data information.",
            "models": "The following models, algorithms, or analytical frameworks are explicitly reported.",
            "results": "The main findings directly supported by the retrieved evidence are:",
            "limitations": "The authors report the following limitations:",
            "future_work": "The papers propose the following future research directions:",
            "literature_review": "The retrieved evidence identifies the following relevant literature points:",
            "contributions": "The main contributions and implications explicitly supported by the papers are:",
            "statistical_analysis": "The statistical analyses explicitly reported in the papers include:",
            "variables": "The main variables and constructs examined in the papers include:",
            "theoretical_framework": "The theoretical concepts or frameworks explicitly discussed in the papers include:",
        }
        opening = openings.get(task, "Based on the grounded evidence retrieved from the papers:")

        lines = [opening, ""]
        limit = 10 if task not in {"limitations", "future_work"} else 8
        for _, text in cleaned[:limit]:
            lines.append(f"- {self._polish(text)}")

        return "\n".join(lines)

    def _compose_comparison(self, question, task, cleaned):
        grouped = defaultdict(list)
        titles = {}
        for claim, text in cleaned:
            pid = self._claim_paper_id(claim) or self._paper_from_evidence_id(claim) or "unknown"
            grouped[str(pid)].append(text)
            title = self._claim_paper_title(claim)
            if title and title.lower() not in {str(pid).lower(), f"{pid}.pdf".lower()}:
                titles[str(pid)] = title

        if len(grouped) < 2:
            pid = next(iter(grouped), "unknown")
            label = self._paper_label(pid, titles.get(pid))
            lines = [
                "A complete cross-paper comparison cannot be established because only one paper contributed task-relevant grounded evidence.",
                "",
                f"{label}:",
            ]
            lines.extend(f"- {self._polish(t)}" for t in grouped.get(pid, [])[:8])
            return "\n".join(lines)

        lines = [self._comparison_heading(task), ""]
        for pid in sorted(grouped):
            lines.append(f"### {self._paper_label(pid, titles.get(pid))}")
            lines.append("")
            for text in grouped[pid][:6]:
                lines.append(f"- {self._polish(text)}")
            lines.append("")

        shared = self._shared_points(task, grouped)
        if shared:
            lines.append("### Similarities supported by the evidence")
            lines.append("")
            lines.extend(f"- {x}" for x in shared)
            lines.append("")

        lines.append("### Comparison note")
        lines.append("")
        lines.append(
            "The comparison is restricted to characteristics directly supported by grounded evidence. "
            "Where the retrieved papers do not provide enough evidence for a similarity or difference, no conclusion is inferred."
        )
        return "\n".join(lines).strip()

    @staticmethod
    def _comparison_heading(task):
        return {
            "methodology": "Comparison of the reported methodologies",
            "datasets": "Comparison of sample and data information",
            "models": "Comparison of reported models and analytical frameworks",
            "results": "Comparison of the main findings",
            "limitations": "Comparison of reported limitations",
            "future_work": "Comparison of future research directions",
            "contributions": "Comparison of the main contributions",
            "statistical_analysis": "Comparison of statistical analyses",
            "variables": "Comparison of variables and constructs",
        }.get(task, "Comparison of the retrieved papers")

    @classmethod
    def _shared_points(cls, task, grouped):
        if len(grouped) < 2:
            return []
        concept_terms = {
            "limitations": {
                "generalizability": ("generalizability", "generalisation", "generalization", "cross-cultural", "single country", "sampling"),
                "realism": ("scenario-based", "scenario based", "ecological validity", "actual interaction", "real usage", "working vto"),
                "self-report": ("self-reported", "self reported", "behavioral intentions", "behavioural intentions"),
            },
            "methodology": {
                "survey": ("survey", "questionnaire"),
                "experiment": ("experiment", "experimental", "randomly assigned"),
                "interview": ("interview", "semi-structured"),
            },
            "datasets": {
                "participant sampling": ("participants", "respondents", "sample", "sampling"),
            },
            "results": {
                "statistically evaluated effects": ("significant", "β", "beta", "p <", "mediation", "moderation", "regression"),
            },
        }.get(task, {})

        out = []
        paper_sets = []
        for texts in grouped.values():
            joined = " ".join(texts).lower()
            paper_sets.append({name for name, terms in concept_terms.items() if any(t in joined for t in terms)})
        if not paper_sets:
            return []
        common = set.intersection(*paper_sets)
        descriptions = {
            "generalizability": "Both papers identify a generalizability constraint related to sampling, geography, or population coverage.",
            "realism": "Both papers identify a limitation related to scenario-based or non-fully-real-world VTO use.",
            "self-report": "Both papers use or discuss participant self-reported measures in the retrieved evidence.",
            "survey": "Both papers use questionnaire/survey-based data collection in the retrieved evidence.",
            "experiment": "Both papers include an experimental component in the retrieved evidence.",
            "interview": "Both papers include interview-based evidence in the retrieved evidence.",
            "participant sampling": "Both papers report participant/sample information as part of their research design.",
            "statistically evaluated effects": "Both papers report statistically evaluated effects or relationships.",
        }
        return [descriptions[x] for x in sorted(common) if x in descriptions]

    @staticmethod
    def _claim_text(claim):
        if isinstance(claim, dict):
            return str(claim.get("claim") or claim.get("text") or "").strip()
        return str(getattr(claim, "claim", None) or getattr(claim, "text", None) or "").strip()

    @staticmethod
    def _claim_paper_id(claim):
        if isinstance(claim, dict):
            direct = claim.get("paper_id")
            citations = claim.get("citations", []) or []
            evidence_ids = claim.get("evidence_ids", []) or []
        else:
            direct = getattr(claim, "paper_id", None)
            citations = getattr(claim, "citations", []) or []
            evidence_ids = getattr(claim, "evidence_ids", []) or []
        if direct:
            return str(direct)
        for c in citations:
            value = c.get("paper_id") if isinstance(c, dict) else getattr(c, "paper_id", None)
            if value:
                return str(value)
        return GroundedAnswerSynthesizer._paper_from_evidence_id(claim)

    @staticmethod
    def _paper_from_evidence_id(claim):
        ids = claim.get("evidence_ids", []) if isinstance(claim, dict) else getattr(claim, "evidence_ids", [])
        for value in ids or []:
            value = str(value)
            if "_chunk_" in value:
                return value.split("_chunk_", 1)[0]
        return None

    @staticmethod
    def _claim_paper_title(claim):
        citations = claim.get("citations", []) if isinstance(claim, dict) else getattr(claim, "citations", [])
        for c in citations or []:
            value = c.get("paper_title") if isinstance(c, dict) else getattr(c, "paper_title", None)
            if value:
                return str(value).strip()
        return ""

    @staticmethod
    def _paper_label(paper_id, title=None):
        pid = str(paper_id or "").strip()
        title = str(title or "").strip()
        if title and title.lower() not in {pid.lower(), f"{pid}.pdf".lower()} and title.lower() not in {"paper1", "paper2", "paper 1", "paper 2"}:
            return title
        match = re.fullmatch(r"paper\s*(\d+)", pid, re.I)
        return f"Paper {match.group(1)}" if match else (pid or "Unidentified paper")

    @staticmethod
    def _is_comparison_question(question):
        q = str(question or "").lower()
        return any(x in q for x in (
            "compare", "comparison", "comparative", "difference", "differences",
            "similarity", "similarities", "both papers", "both studies", "all papers",
            "all the papers", "each paper", "across papers", "across studies",
            "between papers", "between studies", "in common", "shared",
        ))

    @staticmethod
    def _clean_text(text):
        text = re.sub(r"\s+", " ", str(text or "")).strip()
        # Common PDF text-extraction artefacts from statistical tables.
        text = re.sub(r"\bR\s*2\s*5\s*(?=[0-9])", "R² = ", text)
        text = re.sub(r"\b([tF])\s*5\s*(?=[0-9])", r"\1 = ", text)
        text = re.sub(r"\bβ\s*5\s*(?=[0-9])", "β = ", text)
        text = re.sub(r"\b(beta)\s*5\s*(?=[0-9])", r"\1 = ", text, flags=re.I)
        text = re.sub(r"\b(p)\s*5\s*(?=[<=>])", r"\1 = ", text, flags=re.I)
        text = re.sub(r"\s+([,.;:])", r"\1", text)
        text = re.sub(r"\b(identityladen)\b", "identity-laden", text, flags=re.I)
        return text

    @staticmethod
    def _is_noise(text):
        t = str(text or "").lower()
        if any(x in t for x in (
            "article processing charges", "declaration of generative ai", "institutional ethics committee",
            "informed consent", "personally identifiable information", "i would recommend",
            "recommend vto to others", "would recommend vto to others", "generative ai and ai-assisted",
        )):
            return True
        if re.search(r"\bet al\.\b", t) and re.search(r"\b20\d{2}\b", t) and len(t.split()) < 45:
            return True
        if re.search(r"\b(?:references|bibliography)\b", t):
            return True
        return False

    @staticmethod
    def _polish(text):
        text = str(text or "").strip()
        text = re.sub(r"^(first|second|third|fourth|fifth|sixth|finally|additionally|in addition),?\s+", "", text, flags=re.I)
        if text and text[-1] not in ".!?":
            text += "."
        return text[0].upper() + text[1:] if text else text
