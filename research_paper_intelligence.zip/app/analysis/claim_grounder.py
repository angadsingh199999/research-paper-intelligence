from app.models.schemas import (
    GroundedClaim,
    GroundedClaims,
    Citation,
)

import re


# ================================================================
# ABBREVIATIONS
#
# Used by _extract_sentences() to avoid false sentence breaks on
# "et al.", "i.e.", "e.g." etc.
# ================================================================
_ABBREVIATIONS = (
    "et al.", "e.g.", "i.e.", "cf.", "vs.", "etc.", "fig.", "eq.",
    "approx.", "dr.", "prof.", "mr.", "mrs.", "ms.", "no.",
)

_SENTENCE_PLACEHOLDER = "\uE000"

# ================================================================
# QUOTE CHARACTERS
#
# Used by _extract_sentences() to avoid splitting inside a still-
# open quotation, e.g. a quoted survey item that itself contains a
# sentence-ending "?" or "." before the closing quote mark.
# ================================================================
_QUOTE_CHARS = ('"', "'", "\u2018", "\u2019", "\u201c", "\u201d")


class ClaimGrounder:
    def __init__(self):
        print("Claim grounding pipeline ready.")

    # ============================================================
    # MAIN GROUNDING METHOD
    # ============================================================
    def ground(self, evidence, task=None, instruction=None, answer=None):
        if not evidence:
            return GroundedClaims(claims=[])

        task = str(task).lower().strip() if task else "question_answering"

        if task == "methodology":
            claims = self._methodology_claims(evidence)
        elif task == "datasets":
            claims = self._dataset_claims(evidence)
        elif task == "models":
            claims = self._model_claims(evidence)
        elif task == "limitations":
            claims = self._limitation_claims(evidence)
        elif task == "future_work":
            claims = self._future_work_claims(evidence)
        elif task == "contributions":
            claims = self._contribution_claims(evidence)
        elif task == "statistical_analysis":
            claims = self._statistical_analysis_claims(evidence)
        elif task == "variables":
            claims = self._variable_claims(evidence)
        elif task == "theoretical_framework":
            claims = self._theory_claims(evidence)
        elif task == "literature_review":
            claims = self._literature_claims(evidence)
        elif task == "results":
            claims = self._result_claims(evidence)
        else:
            claims = self._general_claims(evidence)

        return GroundedClaims(claims=claims)

    # ============================================================
    # HELPERS
    # ============================================================
    def _text(self, item):
        return str(item.get("text", ""))

    def _citation(self, item):
        return Citation(
            paper_id=str(item.get("paper_id", "")),
            paper_title=str(item.get("paper_title", "")),
            page_start=int(item.get("page_start", 0) or 0),
            page_end=int(item.get("page_end", 0) or 0),
            section=str(item.get("section", "")),
            chunk_id=str(item.get("chunk_id", "")),
        )

    def _make_claim(self, text, item):
        chunk_id = str(item.get("chunk_id", ""))
        return GroundedClaim(
            claim=text,
            evidence_ids=[chunk_id] if chunk_id else [],
            citations=[self._citation(item)],
        )

    @staticmethod
    def _claim_text(claim):
        """
        Pull the plain claim text out of a GroundedClaim object (the
        objects _make_claim() produces, exposed via .claim) or a dict
        (defensive fallback for any other claim shape that ends up
        here). This was previously called by _limitation_claims()
        without ever being defined -- that's what caused
        "'ClaimGrounder' object has no attribute '_claim_text'" for
        every limitations question.
        """
        if isinstance(claim, dict):
            return str(claim.get("claim") or claim.get("text") or "").strip()
        return str(getattr(claim, "claim", "") or "").strip()

    # ============================================================
    # METHODOLOGY
    # ============================================================
    def _methodology_claims(self, evidence):
        claims = []
        added = set()

        # ------------------------------------------------------------
        # Cap how many claims a single evidence chunk may contribute,
        # so one dense chunk can't exhaust the final budget before
        # later chunks (e.g. from a second paper) are reached.
        # ------------------------------------------------------------
        MAX_CLAIMS_PER_CHUNK = 2

        positive_terms = (
            "methodology", "method", "methods", "research design",
            "experimental design", "participants", "participant",
            "sample", "sampling", "questionnaire", "survey", "interview",
            "data collection", "data were collected", "data was collected",
            "randomly assigned", "random assignment", "likert",
            "procedure", "measurement", "measured", "mixed-method",
            "mixed methods", "multi-phase", "experiment", "experimental",
            "qualtrics",
        )

        excluded_terms = (
            "future research", "future studies", "future work",
            "future research should", "could extend", "could examine",
            "could explore", "limitations", "limitation",
            "generalizability", "theoretical contribution",
            "practical contribution", "significantly increased",
            "major environmental", "operational challenges",
        )

        for item in evidence:
            text = self._text(item)
            if not text:
                continue

            lower = text.lower()
            section = str(item.get("section", "")).lower().strip()

            # --------------------------------------------------------
            # Never use these sections as primary methodology evidence.
            #
            # "introduction" was added here: intro sections routinely
            # describe gaps in *other* studies' methodology ("no
            # mixed-methods studies have integrated...") using the
            # same vocabulary (e.g. "mixed-method") that the positive
            # signal checks below look for, which previously let a
            # claim about prior literature's shortcomings get mistaken
            # for the current paper's own methodology.
            # --------------------------------------------------------
            if any(
                term in section
                for term in (
                    "reference", "appendix", "future", "limitation",
                    "discussion", "results", "finding", "conclusion",
                    "literature", "theoretical background", "introduction",
                )
            ):
                continue

            claims_before = len(claims)

            def _under_cap():
                return (len(claims) - claims_before) < MAX_CLAIMS_PER_CHUNK

            if _under_cap() and "between-subjects" in lower and "experimental" in lower:
                claim = (
                    "The researchers used between-subjects experimental "
                    "studies in a Virtual Try-On (VTO) online shopping "
                    "scenario."
                )
                if claim not in added:
                    claims.append(self._make_claim(claim, item))
                    added.add(claim)

            if _under_cap() and "qualtrics" in lower and (
                "questionnaire" in lower or "survey" in lower
            ):
                claim = (
                    "Data was collected through structured online "
                    "questionnaires administered via Qualtrics."
                )
                if claim not in added:
                    claims.append(self._make_claim(claim, item))
                    added.add(claim)

            if _under_cap() and "convenience sampling" in lower and "snowball" in lower:
                claim = (
                    "Participants were recruited using a convenience "
                    "sampling approach combined with a snowball "
                    "technique."
                )
                if claim not in added:
                    claims.append(self._make_claim(claim, item))
                    added.add(claim)

            if _under_cap() and (
                "randomly assigned" in lower or "random assignment" in lower
            ):
                claim = (
                    "Participants were randomly assigned to the "
                    "experimental conditions."
                )
                if claim not in added:
                    claims.append(self._make_claim(claim, item))
                    added.add(claim)

            if _under_cap() and (
                "seven-point likert" in lower
                or "7-point likert" in lower
                or "seven point likert" in lower
            ):
                claim = (
                    "The study used seven-point Likert scales to "
                    "measure the research constructs."
                )
                if claim not in added:
                    claims.append(self._make_claim(claim, item))
                    added.add(claim)

            if _under_cap() and "pre-test" in lower and "brand" in lower:
                claim = (
                    "A pre-test was conducted to validate the luxury "
                    "versus non-luxury brand manipulation."
                )
                if claim not in added:
                    claims.append(self._make_claim(claim, item))
                    added.add(claim)

            # Generic extraction for papers with different wording.
            for sentence in self._extract_sentences(text):
                if not _under_cap():
                    break

                sentence_clean = " ".join(sentence.split()).strip()
                sentence_lower = sentence_clean.lower()

                if len(sentence_clean) < 35:
                    continue
                if any(term in sentence_lower for term in excluded_terms):
                    continue

                signal_count = sum(
                    term in sentence_lower for term in positive_terms
                )
                strong_signal = any(
                    term in sentence_lower
                    for term in (
                        "research design", "experimental design",
                        "between-subjects", "within-subjects",
                        "mixed-method", "mixed methods", "multi-phase",
                        "participants were", "participants", "sample of",
                        "sampling", "questionnaire", "survey was",
                        "survey data", "interviews were",
                        "data were collected", "data was collected",
                        "randomly assigned", "researchers conducted interviews",
                        "procedure",
                    )
                )

                if not strong_signal and signal_count < 2:
                    continue
                if sentence_clean in added:
                    continue

                claims.append(self._make_claim(sentence_clean, item))
                added.add(sentence_clean)

        final_cap = max(12, len(evidence) * MAX_CLAIMS_PER_CHUNK)
        return claims[:final_cap]

    # ============================================================
    # DATASETS
    # ============================================================
    def _dataset_claims(self, evidence):
        claims = []
        added = set()
        for item in evidence:
            text = self._text(item)
            lower = text.lower()
            if "final sample" in lower or "responses" in lower or "participants" in lower:
                for sentence in self._extract_sentences(text):
                    sentence_lower = sentence.lower()
                    if (
                        "sample" in sentence_lower
                        or "responses" in sentence_lower
                        or "participants" in sentence_lower
                    ):
                        claim = sentence.strip()
                        if len(claim) > 20 and claim not in added:
                            claims.append(self._make_claim(claim, item))
                            added.add(claim)
        return claims[:6]

    # ============================================================
    # MODELS
    # ============================================================
    def _model_claims(self, evidence):
        claims = []
        added = set()
        for item in evidence:
            text = self._text(item)
            lower = text.lower()
            if "model" in lower or "algorithm" in lower or "architecture" in lower:
                for sentence in self._extract_sentences(text):
                    sentence_lower = sentence.lower()
                    if (
                        "model" in sentence_lower
                        or "algorithm" in sentence_lower
                        or "architecture" in sentence_lower
                    ):
                        claim = sentence.strip()
                        if len(claim) > 20 and claim not in added:
                            claims.append(self._make_claim(claim, item))
                            added.add(claim)
        return claims[:6]

    # ============================================================
    # LIMITATIONS
    #
    # NOTE: previously this method was defined TWICE in this file.
    # The first definition (a plain _keyword_sentence_claims call)
    # was dead code -- Python only keeps the last definition of a
    # method with the same name, so it was silently discarded and
    # never ran. This is now the only definition. It ALSO relies on
    # _claim_text() (added above), which was never defined anywhere
    # in this class -- that missing method was the actual crash:
    # "'ClaimGrounder' object has no attribute '_claim_text'" for
    # every limitations question.
    # ============================================================
    def _limitation_claims(self, evidence):
        """
        Extract limitation claims with per-paper coverage.
        """
        keywords = [
            "limitation", "limitations", "self-reported",
            "generalizability", "generalisation", "generalization",
            "did not account", "ecological validity", "scenario-based",
            "convenience sampling", "snowball sampling", "single country",
            "cross-cultural", "not directly measured",
            "not empirically tested", "imagined", "actual interaction",
            "real usage", "field experiment", "laboratory", "lab study",
        ]

        grouped = {}
        for item in evidence:
            paper_id = (
                item.get("paper_id")
                if isinstance(item, dict)
                else getattr(item, "paper_id", None)
            )
            grouped.setdefault(str(paper_id or "__unknown__"), []).append(item)

        per_paper = [
            self._keyword_sentence_claims(paper_evidence, keywords, max_claims=6)
            for paper_evidence in grouped.values()
        ]

        result, seen = [], set()
        max_total = max(12, len(grouped) * 6)
        index = 0

        while len(result) < max_total:
            added = False
            for claims in per_paper:
                if index >= len(claims):
                    continue
                claim = claims[index]
                text = self._claim_text(claim)
                if text and text not in seen:
                    result.append(claim)
                    seen.add(text)
                    added = True
            if not added:
                break
            index += 1

        return result

    # ============================================================
    # FUTURE WORK
    # ============================================================
    def _future_work_claims(self, evidence):
        return self._keyword_sentence_claims(
            evidence,
            [
                "future research", "future work", "future studies",
                "further research", "research directions",
                "future investigation", "future research could",
                "future research should",
            ],
            max_claims=6,
        )

    # ============================================================
    # LITERATURE REVIEW
    # ============================================================
    def _literature_claims(self, evidence):
        return self._keyword_sentence_claims(
            evidence,
            ["previous research", "prior research", "literature", "studies"],
            max_claims=6,
        )

    # ============================================================
    # RESULTS
    # ============================================================
    def _result_claims(self, evidence):
        return self._keyword_sentence_claims(
            evidence,
            [
                "significant", "supported", "p <", "beta", "β", "r²",
                "r-squared", "confidence interval", "effect size", "anova",
                "regression", "mediation", "moderation",
            ],
            max_claims=6,
        )

    # ============================================================
    # GENERAL
    # ============================================================
    def _general_claims(self, evidence):
        claims = []
        for item in evidence[:5]:
            sentences = self._extract_sentences(self._text(item))
            if not sentences:
                continue
            claim = sentences[0].strip()
            if len(claim) < 20:
                continue
            claims.append(self._make_claim(claim, item))
        return claims[:5]

    # ============================================================
    # GENERIC SENTENCE EXTRACTION
    # ============================================================
    def _keyword_sentence_claims(self, evidence, keywords, max_claims=6):
        claims = []
        added = set()
        for item in evidence:
            text = self._text(item)
            for sentence in self._extract_sentences(text):
                sentence = self._clean_claim_text(sentence)
                lower = sentence.lower()
                if len(sentence) < 25:
                    continue
                if self._is_noise_claim(lower):
                    continue
                if not any(keyword.lower() in lower for keyword in keywords):
                    continue
                key = " ".join(lower.split())
                if key in added:
                    continue
                claims.append(self._make_claim(sentence, item))
                added.add(key)
                if len(claims) >= max_claims:
                    return claims
        return claims

    @staticmethod
    def _clean_claim_text(text):
        text = re.sub(r"\s+", " ", str(text or "")).strip()
        text = re.sub(r"\s+([,.;:])", r"\1", text)
        text = re.sub(r"\bR\s*2\s*5\s*(?=[0-9])", "R² = ", text)
        text = re.sub(r"\b([tF])\s*5\s*(?=[0-9])", r"\1 = ", text)
        text = re.sub(r"\bβ\s*5\s*(?=[0-9])", "β = ", text)
        text = re.sub(r"\b(beta)\s*5\s*(?=[0-9])", r"\1 = ", text, flags=re.I)
        return text

    @staticmethod
    def _is_noise_claim(text):
        t = " ".join(str(text or "").lower().split())
        if any(x in t for x in (
            "article processing charges", "declaration of generative ai",
            "institutional ethics committee", "informed consent",
            "personally identifiable information", "i would recommend",
            "recommend vto to others", "generative ai and ai-assisted",
        )):
            return True
        if re.search(r"\bet al\.\b", t) and re.search(r"\b20\d{2}\b", t) and len(t.split()) < 45:
            return True
        if re.search(r"\b(references|bibliography)\b", t):
            return True
        return False

    # ============================================================
    # SENTENCE SPLITTER
    # ============================================================
    def _extract_sentences(self, text):
        if not text:
            return []

        text = text.replace("\n", " ").replace("  ", " ")

        # ----------------------------------------------------
        # Protect known abbreviations from being treated as
        # sentence boundaries.
        # ----------------------------------------------------
        protected = text
        for abbreviation in _ABBREVIATIONS:
            protected = re.sub(
                re.escape(abbreviation),
                abbreviation.replace(".", _SENTENCE_PLACEHOLDER),
                protected,
                flags=re.IGNORECASE,
            )

        raw_pieces = re.split(r"(?<=[.!?])\s+", protected)

        # ----------------------------------------------------
        # Re-merge any split that occurred while inside an
        # unbalanced quote -- e.g. a quoted survey item
        # containing its own "?" or "." before the closing
        # quote mark. We track how many quote characters have
        # been seen so far; while that count is odd, we're
        # still "inside" a quote and must not finalize the
        # sentence yet.
        # ----------------------------------------------------
        merged = []
        buffer = ""
        quote_balance = 0
        for piece in raw_pieces:
            buffer = f"{buffer} {piece}".strip() if buffer else piece
            quote_balance += sum(piece.count(q) for q in _QUOTE_CHARS)
            if quote_balance % 2 == 0:
                merged.append(buffer)
                buffer = ""
        if buffer:
            merged.append(buffer)

        sentences = []
        for sentence in merged:
            sentence = sentence.replace(_SENTENCE_PLACEHOLDER, ".").strip()
            if len(sentence) > 10:
                sentences.append(sentence)

        return sentences

    # ============================================================
    # ADDITIONAL RESEARCH TASKS
    # ============================================================
    def _contribution_claims(self, evidence):
        return self._keyword_sentence_claims(
            evidence,
            [
                "theoretical contribution", "practical contribution",
                "managerial implication", "contribution", "novel",
                "extends", "advances", "implication", "adds to",
            ],
            max_claims=8,
        )

    def _statistical_analysis_claims(self, evidence):
        return self._keyword_sentence_claims(
            evidence,
            [
                "pca", "principal component analysis", "regression",
                "anova", "mediation", "moderation", "bootstrap",
                "confidence interval", "hypothesis testing",
                "structural equation", "process macro", "variance",
                "factor analysis",
            ],
            max_claims=8,
        )

    def _variable_claims(self, evidence):
        return self._keyword_sentence_claims(
            evidence,
            [
                "variable", "variables", "construct", "constructs",
                "predictor", "mediator", "moderator", "dependent variable",
                "independent variable", "factor", "perceived usefulness",
                "attitude", "willingness to buy",
            ],
            max_claims=8,
        )

    def _theory_claims(self, evidence):
        return self._keyword_sentence_claims(
            evidence,
            [
                "theory", "theoretical framework", "theoretical model",
                "theoretical background", "theoretical perspective",
                "symbolic", "technology acceptance", "e-tam",
            ],
            max_claims=8,
        )
