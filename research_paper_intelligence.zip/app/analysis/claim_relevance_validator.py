from sentence_transformers import CrossEncoder
import re


class ClaimRelevanceValidator:
    """Rank already-grounded claims using semantic and task-aware signals."""

    TASK_POSITIVE = {
        "methodology": ("method", "methodology", "design", "procedure", "data collection", "sampling", "participants", "questionnaire", "survey", "interview", "measurement", "experiment"),
        "datasets": ("dataset", "sample", "participants", "respondents", "responses", "data source", "retained", "collected"),
        "models": ("model", "algorithm", "architecture", "framework", "classifier", "embedding", "transformer"),
        "results": ("result", "results", "finding", "findings", "effect", "significant", "supported", "β", "beta", "p <", "confidence interval", "mediation", "moderation", "regression", "anova"),
        "limitations": ("limitation", "limitations", "weakness", "constraint", "generalizability", "generalisation", "self-reported", "ecological validity", "scenario-based", "did not account", "not directly measured", "not empirically tested", "convenience sampling", "snowball", "single country", "imagined"),
        "future_work": ("future research", "future work", "future studies", "further research", "research directions", "longitudinal", "should", "could", "recommend", "actual interaction", "working vto", "field experiment"),
        "literature_review": ("literature", "previous research", "prior research", "prior studies", "related work", "theoretical background"),
        "contributions": ("contribution", "contributions", "theoretical", "practical", "managerial", "novel", "extends", "advances", "implication", "implications", "adds to"),
        "statistical_analysis": ("pca", "principal component", "regression", "anova", "mediation", "moderation", "bootstrap", "confidence interval", "hypothesis test", "structural equation", "sem", "process macro", "variance", "r²", "r2", "β", "beta"),
        "variables": ("variable", "variables", "construct", "constructs", "predictor", "mediator", "moderator", "dependent", "independent", "factor", "perceived usefulness", "attitude", "willingness"),
    }

    TASK_NEGATIVE = {
        "results": ("future research", "future work", "limitation", "i would recommend", "ethical statement"),
        "limitations": ("future research", "future work", "i would recommend", "ethical statement", "informed consent", "article processing charges", "declaration of generative ai"),
        "future_work": ("i would recommend", "i would", "ethical statement", "informed consent", "article processing charges", "declaration of generative ai", "references", "bibliography"),
        "contributions": ("pca was", "principal component analysis was", "questionnaire", "participants were", "sample was", "data were collected", "statistical analysis"),
        "statistical_analysis": ("future research", "limitation", "i would recommend", "ethical statement"),
        "methodology": ("future research", "limitation", "references", "bibliography"),
    }

    def __init__(self, model_name="cross-encoder/ms-marco-MiniLM-L-6-v2"):
        print("Loading claim relevance model:")
        print(model_name)
        self.model = CrossEncoder(model_name)
        print("Claim relevance model loaded.")

    def score_claims(self, question, claims, task=None):
        if not claims:
            return []

        valid = []
        pairs = []
        task = str(task or "").lower().strip()
        for claim in claims:
            text = self._claim_text(claim)
            if not text or self._looks_like_noise(text):
                continue
            valid.append(claim)
            pairs.append([str(question), text])

        if not pairs:
            return []

        semantic_scores = self.model.predict(pairs)
        scored = []
        positive = self.TASK_POSITIVE.get(task, ())
        negative = self.TASK_NEGATIVE.get(task, ())

        q_tokens = set(re.findall(r"[a-z0-9]{4,}", str(question).lower()))
        for claim, semantic in zip(valid, semantic_scores):
            text = self._claim_text(claim)
            low = text.lower()
            bonus = 0.0
            for term in positive:
                if term in low:
                    bonus += 0.55
            for term in negative:
                if term in low:
                    bonus -= 1.50
            c_tokens = set(re.findall(r"[a-z0-9]{4,}", low))
            lexical = len(q_tokens & c_tokens) / max(1, len(q_tokens))
            score = float(semantic) + bonus + 0.75 * lexical
            scored.append({"claim": claim, "relevance_score": score})

        scored.sort(key=lambda x: x["relevance_score"], reverse=True)
        return scored

    def filter_claims(self, question, claims, task=None, max_claims=5):
        scored = self.score_claims(question, claims, task=task)
        if not scored:
            return []

        # Keep only task-compatible claims when the task is known.  A small
        # semantic fallback is retained for open-ended QA only.
        task = str(task or "").lower().strip()
        if task in self.TASK_POSITIVE:
            compatible = []
            for item in scored:
                text = self._claim_text(item["claim"]).lower()
                pos = any(t in text for t in self.TASK_POSITIVE[task])
                neg = any(t in text for t in self.TASK_NEGATIVE.get(task, ()))
                if pos and not neg and not self._looks_like_noise(text):
                    compatible.append(item)
            if compatible:
                scored = compatible
            else:
                # Do not invent a claim. If no claim survives the strict task
                # gate, returning nothing is safer than returning wrong content.
                return []

        return [x["claim"] for x in scored[:max(1, int(max_claims))]]

    @staticmethod
    def _claim_text(claim):
        if isinstance(claim, dict):
            return str(claim.get("claim") or claim.get("text") or "").strip()
        return str(getattr(claim, "claim", None) or getattr(claim, "text", None) or "").strip()

    @staticmethod
    def _looks_like_noise(text):
        t = " ".join(str(text or "").lower().split())
        if not t:
            return True
        if any(p in t for p in (
            "article processing charges",
            "declaration of generative ai",
            "institutional ethics committee",
            "informed consent",
            "personally identifiable information",
            "i would recommend",
            "would recommend vto to others",
        )):
            return True
        if re.search(r"\bet al\.\b", t) and re.search(r"\b20\d{2}\b", t) and len(t.split()) < 40:
            return True
        return False
