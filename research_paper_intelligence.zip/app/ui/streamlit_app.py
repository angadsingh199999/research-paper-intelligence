from pathlib import Path
import streamlit as st

from app.ingestion.ingest import ingest_paper
from app.indexing.chunker import create_chunks
from app.retrieval.bm25_retriever import BM25Retriever
from app.retrieval.vector_retriever import VectorRetriever
from app.retrieval.hybrid_retriever import HybridRetriever
from app.retrieval.task_retriever import TaskSpecificRetriever
from app.analysis.claim_grounder import ClaimGrounder
from app.analysis.claim_relevance_validator import ClaimRelevanceValidator
from app.analysis.qa_analyzer import QAAnalyzer


RAW_PAPERS_DIR = Path("data/raw_papers")


st.set_page_config(
    page_title="Research Paper Intelligence",
    page_icon="📄",
    layout="wide",
)


@st.cache_resource(show_spinner=False)
def build_pipeline(pdf_signature):
    pdf_paths = sorted(RAW_PAPERS_DIR.glob("*.pdf"))

    papers = []
    all_chunks = []

    for pdf_path in pdf_paths:
        paper = ingest_paper(str(pdf_path))
        chunks = create_chunks(paper)

        papers.append(paper)
        all_chunks.extend(chunks)

    if not all_chunks:
        return None, [], []

    bm25 = BM25Retriever(all_chunks)
    vector = VectorRetriever(top_k=10)

    hybrid = HybridRetriever(
        bm25,
        vector,
    )

    task_retriever = TaskSpecificRetriever(
        hybrid
    )

    qa = QAAnalyzer(
        task_retriever=task_retriever,
        claim_grounder=ClaimGrounder(),
        claim_relevance_validator=ClaimRelevanceValidator(),
    )

    return qa, papers, all_chunks


def signature():
    files = sorted(RAW_PAPERS_DIR.glob("*.pdf"))
    return tuple(
        (
            str(p),
            p.stat().st_mtime_ns,
            p.stat().st_size,
        )
        for p in files
    )


st.title("📄 Research Paper Intelligence")
st.caption(
    "Automatic multi-paper research QA with grounded evidence, "
    "citations and reliability checks."
)

uploaded = st.file_uploader(
    "Upload PDF files",
    type=["pdf"],
    accept_multiple_files=True,
)

if uploaded:
    RAW_PAPERS_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    for file in uploaded:
        destination = RAW_PAPERS_DIR / Path(file.name).name
        destination.write_bytes(file.getbuffer())

    st.success(
        f"{len(uploaded)} PDF file(s) added to data/raw_papers/."
    )
    st.cache_resource.clear()
    st.rerun()


pdf_paths = sorted(RAW_PAPERS_DIR.glob("*.pdf"))

st.sidebar.subheader("Papers in folder")
st.sidebar.write(f"Total PDFs: {len(pdf_paths)}")

for pdf_path in pdf_paths:
    st.sidebar.write(f"• {pdf_path.name}")

if not pdf_paths:
    st.info(
        "Add PDF files to data/raw_papers/ or upload them above."
    )
    st.stop()


qa, papers, chunks = build_pipeline(
    signature()
)

if qa is None:
    st.error("No chunks could be created from the PDFs.")
    st.stop()

st.write(
    f"**Loaded:** {len(papers)} papers · "
    f"**{len(chunks)} chunks**"
)

question = st.text_area(
    "Enter your research question",
    placeholder=(
        "Example: Compare the methodologies and limitations "
        "of all the papers."
    ),
    height=140,
)

if st.button(
    "🧠 Analyze Research Papers",
    type="primary",
    use_container_width=True,
):
    if not question.strip():
        st.warning("Please enter a research question.")
        st.stop()

    with st.spinner("Retrieving, grounding and synthesizing evidence..."):
        result = qa.answer(question)

    st.divider()
    st.header("📝 Answer")

    # The answer field is the ONLY thing rendered as the main answer.
    # Claims/evidence are shown separately below.
    st.markdown(result.get("answer", ""))

    st.divider()
    st.subheader("Answer reliability")

    confidence = result.get("confidence", {})
    c1, c2 = st.columns(2)

    with c1:
        st.metric(
            "Confidence",
            f"{float(confidence.get('score', 0.0)):.1f}%",
        )

    with c2:
        st.metric(
            "Level",
            confidence.get("label", "LOW"),
        )

    st.caption(
        confidence.get(
            "explanation",
            "Reliability is a heuristic grounded-evidence score.",
        )
    )

    st.divider()
    st.subheader("Sources")

    sources = result.get("sources", [])
    if sources:
        for source in sources:
            title = (
                source.get("paper_title")
                or source.get("paper_id")
                or "Paper"
            )
            pages = (
                f"pp. {source.get('page_start')}"
                if source.get("page_start") == source.get("page_end")
                else f"pp. {source.get('page_start')}–{source.get('page_end')}"
            )
            st.markdown(
                f"- **{title}** — {pages}"
            )
    else:
        st.write("No citation records were generated.")

    with st.expander("Grounded evidence details"):
        for claim in result.get("claims", []):
            st.markdown(
                f"**Claim:** {getattr(claim, 'claim', '')}"
            )
            for citation in getattr(claim, "citations", []) or []:
                st.caption(
                    f"{citation.paper_title or citation.paper_id} · "
                    f"pp. {citation.page_start}–{citation.page_end} · "
                    f"{citation.section}"
                )

    with st.expander("Support check"):
        hallucination = result.get("hallucination", {})
        st.write(
            "Supported:",
            "Yes" if hallucination.get("supported") else "No",
        )
        st.write(
            "Hallucination detected:",
            "Yes"
            if hallucination.get("hallucination_detected")
            else "No",
        )

    st.caption(
        f"Detected task: {result.get('task', 'question_answering')}"
    )
