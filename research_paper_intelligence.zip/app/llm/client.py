from ollama import chat


class LLMClient:

    def __init__(
        self,
        model="qwen3:1.7b"
    ):
        self.model = model

    # ========================================================
    # NORMAL GENERATION
    # ========================================================

    def generate(
        self,
        instructions,
        input_text
    ):

        response = chat(
            model=self.model,
            messages=[
                {
                    "role": "system",
                    "content": instructions
                },
                {
                    "role": "user",
                    "content": input_text
                }
            ],
            options={
                "temperature": 0.1
            }
        )

        return response.message.content

    # ========================================================
    # STRUCTURED GENERATION
    # ========================================================

    def generate_structured(
        self,
        instructions,
        input_text,
        schema
    ):

        # ----------------------------------------------------
        # Pydantic schema
        # ----------------------------------------------------

        if hasattr(
            schema,
            "model_json_schema"
        ):

            output_format = (
                schema.model_json_schema()
            )

        # ----------------------------------------------------
        # Dictionary schema
        # ----------------------------------------------------

        elif isinstance(
            schema,
            dict
        ):

            output_format = schema

        # ----------------------------------------------------
        # Fallback
        # ----------------------------------------------------

        else:

            output_format = {
                "type": "object"
            }

        response = chat(
            model=self.model,
            messages=[
                {
                    "role": "system",
                    "content": instructions
                },
                {
                    "role": "user",
                    "content": input_text
                }
            ],
            format=output_format,
            options={
                "temperature": 0.1
            }
        )

        return response.message.content
