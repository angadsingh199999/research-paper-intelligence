from sentence_transformers import SentenceTransformer


class EmbeddingModel:

    def __init__(
        self,
        model_name="BAAI/bge-small-en-v1.5"
    ):

        print(
            f"Loading embedding model: "
            f"{model_name}"
        )

        self.model = SentenceTransformer(
            model_name
        )

        print("Embedding model loaded.")

    def encode(
        self,
        texts,
        normalize_embeddings=True
    ):

        embeddings = self.model.encode(
            texts,
            normalize_embeddings=normalize_embeddings,
            show_progress_bar=True
        )

        return embeddings

    def encode_query(self, query):

        return self.model.encode(
            query,
            normalize_embeddings=True
        )