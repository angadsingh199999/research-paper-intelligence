import chromadb


class ChromaVectorStore:

    def __init__(
        self,
        persist_directory="data/chroma",
        collection_name="research_papers"
    ):

        self.client = chromadb.PersistentClient(
            path=persist_directory
        )

        self.collection = (
            self.client.get_or_create_collection(
                name=collection_name
            )
        )

    # ========================================================
    # ADD CHUNKS
    # ========================================================

    def add_chunks(
        self,
        chunks,
        embeddings
    ):

        ids = [
            chunk.chunk_id
            for chunk in chunks
        ]

        documents = [
            chunk.text
            for chunk in chunks
        ]

        metadatas = [
            {
                "paper_id": chunk.paper_id,

                "paper_title": chunk.paper_title,

                "section": chunk.section,

                "page_start": chunk.page_start,

                "page_end": chunk.page_end,

                "word_count": chunk.word_count
            }

            for chunk in chunks
        ]

        self.collection.add(
            ids=ids,
            documents=documents,
            embeddings=embeddings.tolist(),
            metadatas=metadatas
        )

    # ========================================================
    # COUNT
    # ========================================================

    def count(self):

        return self.collection.count()
