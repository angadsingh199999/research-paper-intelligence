from typing import List
from pydantic import BaseModel, Field


class PaperMetadata(BaseModel):
    paper_id: str = ""
    filename: str = ""
    title: str = ""
    authors: List[str] = Field(default_factory=list)
    total_pages: int = 0


class SectionBlock(BaseModel):
    section: str = ""
    text: str = ""
    page_number: int = 0


class Page(BaseModel):
    page_number: int = 0
    blocks: List[SectionBlock] = Field(default_factory=list)


class ResearchPaper(BaseModel):
    metadata: PaperMetadata
    pages: List[Page] = Field(default_factory=list)


class Chunk(BaseModel):
    chunk_id: str = ""
    paper_id: str = ""
    paper_title: str = ""
    section: str = ""
    text: str = ""
    page_start: int = 0
    page_end: int = 0
    word_count: int = 0


class Citation(BaseModel):
    paper_id: str = ""
    paper_title: str = ""
    page_start: int = 0
    page_end: int = 0
    section: str = ""
    chunk_id: str = ""


class GroundedClaim(BaseModel):
    claim: str
    evidence_ids: List[str] = Field(default_factory=list)
    citations: List[Citation] = Field(default_factory=list)

    # Internal ranking signal. Never display this directly in the UI.
    relevance_score: float = 0.0


class GroundedClaims(BaseModel):
    claims: List[GroundedClaim] = Field(default_factory=list)


class QAResponse(BaseModel):
    answer: str
    task: str
    claims: List[GroundedClaim] = Field(default_factory=list)
    evidence: list = Field(default_factory=list)
    task_scores: dict = Field(default_factory=dict)
