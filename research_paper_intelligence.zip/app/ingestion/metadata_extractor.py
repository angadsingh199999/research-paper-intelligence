import re
from pathlib import Path


def extract_metadata(pages, pdf_path):
    """
    Extract basic metadata from the first page of a research paper.

    Returns:
        Dictionary containing paper metadata.
    """

    filename = Path(pdf_path).name
    paper_id = Path(pdf_path).stem

    first_page_text = pages[0]["text"]

    lines = [
        line.strip()
        for line in first_page_text.splitlines()
        if line.strip()
    ]

    title = ""
    authors = []

    # --------------------------------------------------------
    # Find the Abstract heading.
    #
    # Previously this only matched a line that was EXACTLY
    # "abstract" (case-insensitive) and nothing else. Many PDFs
    # extract the heading merged with the text that follows it
    # on the same line (e.g. "Abstract This study investigates
    # ..."), or with trailing running-header/footer text, so an
    # exact match silently fails and title/authors are never
    # extracted -- this is what happened for paper2. Matching a
    # line that STARTS WITH "abstract" (as its own word, not a
    # substring like "Abstractly") catches both the old exact
    # case and the merged-line case.
    # --------------------------------------------------------
    abstract_index = None

    for i, line in enumerate(lines):
        normalized = line.strip().lower()

        if normalized == "abstract" or re.match(
            r"^abstract\b", normalized
        ):
            abstract_index = i
            break

    if abstract_index is not None:

        # Everything before Abstract
        header_lines = lines[:abstract_index]

        if len(header_lines) >= 2:
            title = " ".join(header_lines[:-2])

            author_line = header_lines[-2]

            authors = [
                author.strip()
                for author in re.split(r",|\band\b", author_line)
                if author.strip()
            ]

    title = title.strip()

    # --------------------------------------------------------
    # Guaranteed fallback.
    #
    # If the Abstract heading was never found, or the header
    # region didn't yield a usable title, don't leave title as
    # an empty string -- that surfaces as a blank paper name
    # throughout the UI (paper cards, citations, comparisons).
    # Fall back to a readable version of the filename so the
    # paper is always identifiable, even if the "real" title
    # extraction from the PDF text failed.
    # --------------------------------------------------------
    if not title:
        readable_stem = re.sub(r"[_\-]+", " ", paper_id).strip()
        title = readable_stem if readable_stem else filename

    metadata = {
        "paper_id": paper_id,
        "filename": filename,
        "title": title,
        "authors": authors,
        "total_pages": len(pages),
    }

    return metadata
