import re


# ================================================================
# STATISTICAL NOTATION REPAIR
#
# Some PDFs (particularly journal exports with non-standard math
# fonts) have a broken character map: the glyph for "=" gets
# extracted by pymupdf as a literal digit "5", and the glyph for
# "-" / "−" (minus) gets extracted as "Ø". This has been showing up
# throughout this project's evidence text: "F(2, 124) 5 82.96"
# should read "F(2, 124) = 82.96"; "t(177) 5 Ø4.44" should read
# "t(177) = -4.44".
#
# This is a font-encoding problem in the SOURCE PDF, not something
# introduced by our own extraction or cleaning -- pymupdf is
# faithfully reporting what the PDF's (broken) character map says.
# It cannot be fixed with full certainty, because a bare "5" is
# genuinely ambiguous (it might be a real digit 5). The fix below
# is a targeted heuristic: it only converts " 5 " to " = " when it
# sits directly between a recognized statistics symbol/abbreviation
# and a number, which is the specific pattern causing every
# instance observed in this pipeline's evidence. It will NOT catch
# every possible corrupted "5" in every possible PDF -- if you see
# figures that still look wrong after this, that specific pattern
# isn't covered by the symbol list below and the list should be
# extended, not the pattern loosened, to avoid corrupting genuine
# numbers.
# ================================================================

_STAT_LABELS = (
    r"M(?:\s?age)?",
    r"SD(?:\s?age)?",
    r"SE",
    r"N",
    r"n",
    r"df\d*",
    r"F\([^)]{1,20}\)",
    r"t\([^)]{1,20}\)",
    r"r",
    r"R²",
    r"R2",
    r"p",
    r"β",
    r"α",
    r"χ²",
    r"chi2",
    r"d",
    r"k",
    r"z",
    r"CI",
    r"ICC",
    r"AVE",
    r"CR",
    r"ω",
    r"ΔR²",
    r"η[pP]²",
    r"factor",
    r"variance",
    r"loading",
    r"correlation",
    r"coefficient",
)

_STAT_LABEL_GROUP = "|".join(_STAT_LABELS)

# Matches: <stat symbol><space>5<space>, only when followed by an
# optional minus-artifact or dash and then a digit -- e.g.
# "F(2, 124) 5 82.96", "t(177) 5 Ø4.44", "α 5 0.92", "p 5 0.904".
_STAT_EQUALS_PATTERN = re.compile(
    rf"\b(?P<label>{_STAT_LABEL_GROUP})\s5\s(?=[-–—Ø]?\d)"
)

# The "Ø" glyph immediately before a digit is this same font's
# corrupted rendering of a minus sign (e.g. "Ø4.44" -> "-4.44").
# Only replace it directly before a digit, not elsewhere, so an
# unrelated legitimate use of "Ø" (unlikely in this content, but
# not impossible) isn't blindly stripped.
_MINUS_ARTIFACT_PATTERN = re.compile(r"Ø(?=\d)")


def _repair_statistical_notation(text):
    text = _STAT_EQUALS_PATTERN.sub(
        lambda m: f"{m.group('label')} = ",
        text
    )

    text = _MINUS_ARTIFACT_PATTERN.sub("-", text)

    return text


def clean_text(text):
    """
    Clean extracted PDF text while preserving
    meaningful research content.
    """

    # Replace non-breaking spaces
    text = text.replace("\xa0", " ")

    # --------------------------------------------------------
    # Remove soft hyphens (U+00AD) left over from justified-text
    # line wrapping in the source PDF.
    # --------------------------------------------------------
    text = re.sub(r"\xad\s*", "", text)

    # --------------------------------------------------------
    # Repair the "5"-as-"=" and "Ø"-as-"-" font encoding artifacts
    # before whitespace normalization, so the stat-label lookbehind/
    # lookahead patterns above still see the original single-space
    # spacing the PDF produced around these symbols.
    # --------------------------------------------------------
    text = _repair_statistical_notation(text)

    # Remove excessive spaces
    text = re.sub(r"[ \t]+", " ", text)

    # Remove spaces at the beginning/end of lines
    text = "\n".join(line.strip() for line in text.splitlines())

    # Remove excessive blank lines
    text = re.sub(r"\n{3,}", "\n\n", text)

    return text.strip()
