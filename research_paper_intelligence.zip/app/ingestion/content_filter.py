import re


PUBLISHER_PATTERNS = [

    r"^\d{1,2}\s+[A-Za-z]+\s+\d{4}$",

    r"^Accepted\s+\d{1,2}\s+[A-Za-z]+\s+\d{4}$",

    r"^European Journal of Innovation",

    r"^Management$",

    r"^Vol\.\s+\d+",

    r"^pp\.\s+\d+",

    r"^Emerald Publishing",

    r"^e-ISSN:",

    r"^p-ISSN:",

    r"^DOI\s+",

    r"^Downloaded from",

    r"^EJIM\s+\d+,\s*\d+\s+\d+$",

]


# ================================================================
# INLINE ARTIFACT PATTERNS
#
# The whole-line patterns above only ever fire when a publisher
# artifact IS the entire line. In practice, pymupdf's get_text()
# frequently welds a running head + page number onto the END of a
# real content line instead of giving it its own line -- e.g.
# "...191 collected questionnaires, EJIM 29,11 480" or "...via
# Qualtrics. The European Journal of Innovation 477" -- so no
# whole-line filter can ever catch these, regardless of how correct
# its regex is. These patterns are removed via substitution wherever
# they appear in the text, not just when they constitute a full line.
#
# Both require a trailing run of digits directly after the journal
# name/code (the page-number artifact itself), which a genuine
# in-text mention of the journal (e.g. in a literature citation like
# "published in the European Journal of Innovation Management
# (2024)") would not have -- real citations are followed by a year
# in parentheses or further prose, not bare digits with only
# whitespace in between.
# ================================================================

INLINE_ARTIFACT_PATTERNS = [

    r"\bEJIM\s+\d{1,3}\s*,\s*\d{1,3}\s+\d{1,4}\b",

    r"\b(?:The\s+)?European Journal of Innovation(?:\s+Management)?\s+\d{1,4}\b",

]


def is_publisher_line(line):

    line = line.strip()

    if not line:
        return True

    for pattern in PUBLISHER_PATTERNS:

        if re.search(
            pattern,
            line,
            re.IGNORECASE
        ):
            return True

    return False


def remove_publisher_content(text):

    # ------------------------------------------------------------
    # First pass: strip known inline artifacts wherever they occur
    # in the text, before any line-splitting happens. This is what
    # catches the mid-sentence cases the original whole-line filter
    # structurally could not.
    # ------------------------------------------------------------

    for pattern in INLINE_ARTIFACT_PATTERNS:

        text = re.sub(
            pattern,
            " ",
            text,
            flags=re.IGNORECASE
        )

    # ------------------------------------------------------------
    # Second pass: original whole-line filter, unchanged. This still
    # catches genuinely isolated header/footer lines (ISSN, DOI,
    # "Downloaded from...", standalone "Vol./pp." lines, etc.) that
    # do occupy their own line rather than being merged into content.
    # ------------------------------------------------------------

    lines = text.splitlines()

    cleaned_lines = []

    for line in lines:

        if not is_publisher_line(line):

            cleaned_lines.append(line)

    cleaned_text = "\n".join(
        cleaned_lines
    )

    # ------------------------------------------------------------
    # The inline substitution above replaces artifacts with a single
    # space rather than deleting them outright, to avoid accidentally
    # gluing the words on either side of the artifact together (e.g.
    # "Qualtrics.The" instead of "Qualtrics. The"). This can leave
    # doubled-up spacing where the artifact used to sit -- collapse
    # that here rather than in clean_text(), since this is a
    # side-effect specific to this substitution, not general PDF
    # extraction whitespace noise.
    # ------------------------------------------------------------

    cleaned_text = re.sub(
        r"[ \t]{2,}",
        " ",
        cleaned_text
    )

    return cleaned_text
