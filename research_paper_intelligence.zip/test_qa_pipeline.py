from pathlib import Path

from app.ingestion.ingest import ingest_paper
from app.indexing.chunker import create_chunks
from app.retrieval.bm25_retriever import BM25Retriever
from app.retrieval.vector_retriever import VectorRetriever
from app.retrieval.hybrid_retriever import HybridRetriever
from app.retrieval.task_retriever import TaskSpecificRetriever
from app.analysis.claim_grounder import ClaimGrounder
from app.analysis.claim_relevance_validator import ClaimRelevanceValidator
from app.analysis.qa_analyzer import QAAnalyzer


# ============================================================
# CONFIGURATION
# ============================================================

RAW_PAPERS_DIR = Path("data/raw_papers")

# These questions are intentionally different so that the
# complete QA system is tested with different research tasks.
TEST_QUESTIONS = [
    "What methodology did the researchers use?",
    "What are the main findings of the papers?",
    "What limitations are reported in the papers?",
    "Compare the methodologies used in all the papers.",
    "Compare the limitations of all the papers.",
    "What samples or participants were used in each paper?",
    "What future research directions do the authors suggest?",
    "What are the main contributions of each paper?",
]

# Set this to True if you want to stop after the first
# question while debugging.
STOP_AFTER_FIRST_QUESTION = False


# ============================================================
# HELPER FUNCTIONS
# ============================================================

def get_value(obj, key, default=None):
    """Safely read a field from either a dict or an object."""
    if isinstance(obj, dict):
        return obj.get(key, default)

    return getattr(obj, key, default)


def get_claim_paper_ids(claims, evidence):
    """Determine which papers are represented by grounded claims."""

    evidence_by_id = {}

    for item in evidence:
        if not isinstance(item, dict):
            continue

        chunk_id = item.get("chunk_id")

        if chunk_id:
            evidence_by_id[chunk_id] = item

    paper_ids = set()

    for claim in claims:
        direct_paper_id = get_value(
            claim,
            "paper_id",
            None,
        )

        if direct_paper_id:
            paper_ids.add(
                str(direct_paper_id)
            )
            continue

        evidence_ids = get_value(
            claim,
            "evidence_ids",
            [],
        ) or []

        for evidence_id in evidence_ids:
            item = evidence_by_id.get(
                evidence_id
            )

            if item and item.get("paper_id"):
                paper_ids.add(
                    str(item["paper_id"])
                )

    return paper_ids


def print_claims(claims):
    """Print grounded claims in a clean test format."""

    if not claims:
        print("No grounded claims returned.")
        return

    for index, claim in enumerate(
        claims,
        start=1,
    ):
        text = get_value(
            claim,
            "claim",
            None,
        )

        if not text:
            text = get_value(
                claim,
                "text",
                "",
            )

        evidence_ids = get_value(
            claim,
            "evidence_ids",
            [],
        ) or []

        paper_id = get_value(
            claim,
            "paper_id",
            None,
        )

        print(f"\nCLAIM {index}")
        print("-" * 60)

        if paper_id:
            print("Paper ID:", paper_id)

        print("Claim:", text)
        print(
            "Evidence IDs:",
            evidence_ids,
        )


def print_paper_coverage(
    paper_ids,
    claims,
    evidence,
):
    """Print retrieved and grounded paper coverage."""

    retrieved_papers = sorted(
        {
            str(item.get("paper_id"))
            for item in evidence
            if isinstance(item, dict)
            and item.get("paper_id")
        }
    )

    grounded_papers = sorted(
        get_claim_paper_ids(
            claims,
            evidence,
        )
    )

    expected_papers = set(
        str(paper_id)
        for paper_id in paper_ids
    )

    coverage = (
        len(
            set(grounded_papers)
            & expected_papers
        )
        / len(expected_papers)
        if expected_papers
        else 0.0
    )

    print("\nPAPER COVERAGE")
    print("-" * 60)
    print(
        "Papers with retrieved evidence:",
        retrieved_papers,
    )
    print(
        "Papers represented in grounded claims:",
        grounded_papers,
    )
    print(
        f"Grounded paper coverage: "
        f"{coverage * 100:.2f}%"
    )

    return retrieved_papers, grounded_papers, coverage


def run_question(
    qa,
    question,
    paper_ids,
    question_number,
):
    """Run one question through the complete QA pipeline."""

    print("\n\n" + "=" * 80)
    print(
        f"QUESTION {question_number}: "
        f"{question}"
    )
    print("=" * 80)

    result = qa.answer(
        question
    )

    if not isinstance(result, dict):
        raise RuntimeError(
            "QAAnalyzer did not return a dictionary."
        )

    answer = str(
        result.get(
            "answer",
            "",
        )
        or ""
    ).strip()

    claims = result.get(
        "claims",
        [],
    ) or []

    evidence = result.get(
        "evidence",
        [],
    ) or []

    citations = result.get(
        "citations",
        [],
    ) or []

    sources = result.get(
        "sources",
        [],
    ) or []

    task = result.get(
        "task",
        "",
    )

    hallucination = result.get(
        "hallucination",
        {},
    ) or {}

    confidence = result.get(
        "confidence",
        {},
    ) or {}

    # --------------------------------------------------------
    # FINAL ANSWER
    # --------------------------------------------------------

    print("\n" + "=" * 80)
    print("FINAL ANSWER")
    print("=" * 80)

    print(
        answer
        if answer
        else "No answer generated."
    )

    # --------------------------------------------------------
    # TASK
    # --------------------------------------------------------

    print("\n" + "=" * 80)
    print("TASK DETECTION")
    print("=" * 80)

    print(
        "Detected task:",
        task or "N/A",
    )

    # --------------------------------------------------------
    # GROUNDED CLAIMS
    # --------------------------------------------------------

    print("\n" + "=" * 80)
    print("GROUNDED CLAIMS")
    print("=" * 80)

    print(
        "Grounded claim count:",
        len(claims),
    )

    print_claims(
        claims
    )

    # --------------------------------------------------------
    # PAPER COVERAGE
    # --------------------------------------------------------

    (
        retrieved_papers,
        grounded_papers,
        coverage,
    ) = print_paper_coverage(
        paper_ids,
        claims,
        evidence,
    )

    # --------------------------------------------------------
    # CITATIONS
    # --------------------------------------------------------

    print("\n" + "=" * 80)
    print("CITATIONS / SOURCE ATTRIBUTION")
    print("=" * 80)

    print(
        "Claim citation groups:",
        len(citations),
    )

    print(
        "Unique sources:",
        len(sources),
    )

    # --------------------------------------------------------
    # HALLUCINATION CHECK
    # --------------------------------------------------------

    print("\n" + "=" * 80)
    print("HALLUCINATION / SUPPORT CHECK")
    print("=" * 80)

    print(
        "Supported:",
        hallucination.get(
            "supported",
            False,
        ),
    )

    print(
        "Hallucination detected:",
        hallucination.get(
            "hallucination_detected",
            False,
        ),
    )

    print(
        "Support score:",
        hallucination.get(
            "support_score",
            0.0,
        ),
    )

    # --------------------------------------------------------
    # CONFIDENCE
    # --------------------------------------------------------

    print("\n" + "=" * 80)
    print("CONFIDENCE / RELIABILITY")
    print("=" * 80)

    print(
        "Confidence score:",
        confidence.get(
            "score",
            0.0,
        ),
    )

    print(
        "Confidence level:",
        confidence.get(
            "label",
            "LOW",
        ),
    )

    # --------------------------------------------------------
    # QUESTION-SPECIFIC VALIDATION
    # --------------------------------------------------------

    question_lower = question.lower()

    is_comparison = any(
        word in question_lower
        for word in (
            "compare",
            "comparison",
            "both papers",
            "all papers",
            "between the papers",
        )
    )

    print("\n" + "=" * 80)
    print("QUESTION VALIDATION")
    print("=" * 80)

    checks = [
        (
            "Answer generated",
            bool(answer),
        ),
        (
            "Task detected",
            bool(task),
        ),
        (
            "Evidence returned",
            bool(evidence),
        ),
        (
            "Grounded claims returned",
            bool(claims),
        ),
        (
            "Citations returned",
            bool(citations),
        ),
        (
            "Sources returned",
            bool(sources),
        ),
        (
            "Confidence returned",
            isinstance(
                confidence,
                dict,
            ),
        ),
    ]

    if is_comparison:
        checks.append(
            (
                "All papers represented in grounded claims",
                coverage >= 1.0,
            )
        )

    for label, passed in checks:
        print(
            f"[{'PASS' if passed else 'FAIL'}] "
            f"{label}"
        )

    failed = [
        label
        for label, passed in checks
        if not passed
    ]

    # A comparison question without complete paper
    # coverage is important enough to be reported as a
    # warning, but the test continues so all questions
    # can still be inspected.
    if (
        is_comparison
        and coverage < 1.0
    ):
        print(
            "\nWARNING:"
            " This is a comparison question, "
            "but not every paper contributed "
            "a grounded claim."
        )

    return {
        "question": question,
        "answer": answer,
        "task": task,
        "claims": claims,
        "evidence": evidence,
        "citations": citations,
        "sources": sources,
        "retrieved_papers": retrieved_papers,
        "grounded_papers": grounded_papers,
        "coverage": coverage,
        "hallucination": hallucination,
        "confidence": confidence,
        "failed_checks": failed,
        "is_comparison": is_comparison,
    }


# ============================================================
# 1. AUTOMATIC PDF DISCOVERY
# ============================================================

PDF_PATHS = sorted(
    RAW_PAPERS_DIR.glob("*.pdf")
)

if not PDF_PATHS:
    raise RuntimeError(
        f"No PDF files found in "
        f"{RAW_PAPERS_DIR.resolve()}"
    )


print("\n" + "=" * 80)
print("RESEARCH PAPER INTELLIGENCE PIPELINE")
print("=" * 80)

print(
    "PDF directory:",
    RAW_PAPERS_DIR,
)

print(
    "PDF files detected:",
    len(PDF_PATHS),
)

for pdf_path in PDF_PATHS:
    print(
        "  -",
        pdf_path.name,
    )


# ============================================================
# 2. PDF INGESTION
# ============================================================

print("\n" + "=" * 80)
print("STEP 1: PDF INGESTION")
print("=" * 80)

papers = []

for pdf_path in PDF_PATHS:

    print(
        f"\nProcessing: {pdf_path}"
    )

    try:
        paper = ingest_paper(
            str(pdf_path)
        )

    except Exception as exc:
        print(
            f"[FAIL] Could not ingest "
            f"{pdf_path.name}"
        )
        print(
            "Reason:",
            exc,
        )
        continue

    papers.append(
        paper
    )

    paper_id = getattr(
        paper.metadata,
        "paper_id",
        pdf_path.stem,
    )

    title = str(
        getattr(
            paper.metadata,
            "title",
            "",
        )
        or ""
    ).strip()

    if not title:
        title = (
            pdf_path.stem
            .replace("_", " ")
            .strip()
        )

    print(
        "Paper ID:",
        paper_id,
    )

    print(
        "Title:",
        repr(title),
    )

    print(
        "Pages:",
        getattr(
            paper.metadata,
            "total_pages",
            0,
        ),
    )


if not papers:
    raise RuntimeError(
        "No papers were successfully ingested."
    )


print(
    "\nTotal papers ingested:",
    len(papers),
)

print(
    "PDF ingestion successful."
)


# ============================================================
# 3. DOCUMENT CHUNKING
# ============================================================

print("\n" + "=" * 80)
print("STEP 2: DOCUMENT CHUNKING")
print("=" * 80)

all_chunks = []

paper_ids = []

for paper in papers:

    paper_id = str(
        getattr(
            paper.metadata,
            "paper_id",
            "N/A",
        )
    )

    paper_ids.append(
        paper_id
    )

    chunks = create_chunks(
        paper
    )

    if not chunks:
        raise RuntimeError(
            f"No chunks created for "
            f"{paper_id}."
        )

    print(
        f"Paper ID: {paper_id} | "
        f"Chunks: {len(chunks)}"
    )

    all_chunks.extend(
        chunks
    )


if not all_chunks:
    raise RuntimeError(
        "No document chunks were created."
    )


print(
    "\nTotal chunks across all papers:",
    len(all_chunks),
)


# ============================================================
# 4. COMBINED PAPER COLLECTION
# ============================================================

print("\n" + "=" * 80)
print("COMBINED PAPER COLLECTION")
print("=" * 80)

unique_paper_ids = sorted(
    set(paper_ids)
)

print(
    "Paper IDs:",
    unique_paper_ids,
)

for paper_id in unique_paper_ids:

    count = sum(
        1
        for chunk in all_chunks
        if str(
            getattr(
                chunk,
                "paper_id",
                "N/A",
            )
        ) == paper_id
    )

    print(
        f"{paper_id}: "
        f"{count} chunks"
    )


# ============================================================
# 5. RETRIEVAL PIPELINE
# ============================================================

print("\n" + "=" * 80)
print("STEP 3: RETRIEVAL PIPELINE")
print("=" * 80)


# ------------------------------------------------------------
# BM25 lexical retrieval
# ------------------------------------------------------------

bm25 = BM25Retriever(
    all_chunks
)

print(
    "BM25 retriever initialized."
)


# ------------------------------------------------------------
# Vector semantic retrieval
# ------------------------------------------------------------

vector = VectorRetriever(
    top_k=10
)

print(
    "Vector retriever initialized."
)


# ------------------------------------------------------------
# Hybrid retrieval
# ------------------------------------------------------------

# Use keyword arguments deliberately so the two retrievers
# can never be accidentally reversed.
hybrid = HybridRetriever(
    vector_retriever=vector,
    bm25_retriever=bm25,
)

print(
    "Hybrid retriever initialized."
)


# ------------------------------------------------------------
# Task-aware retrieval
# ------------------------------------------------------------

task_retriever = TaskSpecificRetriever(
    hybrid_retriever=hybrid,
    candidate_k=20,
    top_k=8,
)

print(
    "Task-specific retriever initialized."
)

print(
    "Retrieval pipeline ready."
)


# ============================================================
# 6. ANALYSIS COMPONENTS
# ============================================================

print("\n" + "=" * 80)
print("STEP 4: ANALYSIS COMPONENTS")
print("=" * 80)

claim_grounder = ClaimGrounder()

claim_relevance_validator = (
    ClaimRelevanceValidator()
)

print(
    "Claim grounder initialized."
)

print(
    "Claim relevance validator initialized."
)


# ============================================================
# 7. COMPLETE QA ANALYZER
# ============================================================

qa = QAAnalyzer(
    task_retriever=task_retriever,
    claim_grounder=claim_grounder,
    claim_relevance_validator=(
        claim_relevance_validator
    ),
)

print(
    "QA analyzer initialized."
)


# ============================================================
# 8. RUN ALL TEST QUESTIONS
# ============================================================

print("\n" + "=" * 80)
print("STEP 5: MULTI-QUESTION QA TEST")
print("=" * 80)

print(
    f"Questions to test: "
    f"{len(TEST_QUESTIONS)}"
)

results = []

questions_to_run = (
    TEST_QUESTIONS[:1]
    if STOP_AFTER_FIRST_QUESTION
    else TEST_QUESTIONS
)

for question_number, question in enumerate(
    questions_to_run,
    start=1,
):

    try:

        result = run_question(
            qa=qa,
            question=question,
            paper_ids=unique_paper_ids,
            question_number=question_number,
        )

        results.append(
            result
        )

    except Exception as exc:

        print("\n" + "=" * 80)
        print(
            f"QUESTION {question_number} FAILED"
        )
        print("=" * 80)

        print(
            "Question:",
            question,
        )

        print(
            "Reason:",
            exc,
        )

        results.append(
            {
                "question": question,
                "failed_checks": [
                    "Question execution"
                ],
                "execution_error": str(exc),
            }
        )


# ============================================================
# 9. OVERALL TEST SUMMARY
# ============================================================

print("\n\n" + "=" * 80)
print("OVERALL QA TEST SUMMARY")
print("=" * 80)

successful_questions = 0
failed_questions = 0

for index, result in enumerate(
    results,
    start=1,
):

    execution_error = result.get(
        "execution_error"
    )

    failed_checks = result.get(
        "failed_checks",
        [],
    )

    if execution_error:
        status = "FAIL"
        failed_questions += 1

    elif failed_checks:
        status = "CHECK"
        failed_questions += 1

    else:
        status = "PASS"
        successful_questions += 1

    print(
        f"[{status}] "
        f"Q{index}: "
        f"{result.get('question', '')}"
    )

    if result.get(
        "is_comparison",
        False,
    ):
        print(
            "     Grounded paper coverage:",
            f"{result.get('coverage', 0.0) * 100:.2f}%",
        )

    if failed_checks:
        print(
            "     Failed checks:",
            failed_checks,
        )

    if execution_error:
        print(
            "     Execution error:",
            execution_error,
        )


# ============================================================
# 10. MULTI-PAPER COMPARISON SUMMARY
# ============================================================

comparison_results = [
    result
    for result in results
    if result.get(
        "is_comparison",
        False,
    )
]

print("\n" + "=" * 80)
print("MULTI-PAPER COMPARISON VALIDATION")
print("=" * 80)

if not comparison_results:

    print(
        "No comparison questions were executed."
    )

else:

    for result in comparison_results:

        coverage = result.get(
            "coverage",
            0.0,
        )

        question = result.get(
            "question",
            "",
        )

        print(
            f"\nQuestion: {question}"
        )

        print(
            "Grounded paper coverage:",
            f"{coverage * 100:.2f}%",
        )

        if coverage >= 1.0:
            print(
                "[PASS] Every loaded paper "
                "contributed grounded claims."
            )
        else:
            print(
                "[WARNING] Not every loaded paper "
                "contributed grounded claims."
            )


# ============================================================
# 11. FINAL STATUS
# ============================================================

print("\n" + "=" * 80)
print("FINAL TEST STATUS")
print("=" * 80)

print(
    "Papers discovered:",
    len(PDF_PATHS),
)

print(
    "Papers ingested:",
    len(papers),
)

print(
    "Total chunks:",
    len(all_chunks),
)

print(
    "Questions executed:",
    len(results),
)

print(
    "Questions fully passed:",
    successful_questions,
)

print(
    "Questions requiring inspection:",
    failed_questions,
)


if not results:
    raise RuntimeError(
        "No QA questions were executed."
    )


print("\n" + "=" * 80)
print(
    "END-TO-END MULTI-PAPER QA TEST COMPLETE"
)
print("=" * 80)
