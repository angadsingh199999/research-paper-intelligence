TASK_SECTION_RULES = {
    "methodology": {
        "preferred_sections": [
            "method", "methodology", "research design", "experimental design",
            "participants", "sample", "sampling", "procedure",
            "data collection", "measurement", "measures", "materials",
        ],
        "keywords": [
            "methodology", "research design", "experimental design",
            "participants", "sample", "sampling", "questionnaire", "survey",
            "interview", "data collection", "procedure", "measurement",
            "likert", "randomly assigned", "random assignment",
            "between-subjects", "within-subjects", "mixed-method",
            "mixed methods", "qualitative", "quantitative",
        ],
        "excluded_sections": [
            "references", "appendix", "future research", "future work",
            "limitations", "conclusion",
        ],
    },
    "datasets": {
        "preferred_sections": [
            "data", "dataset", "sample", "participants", "respondents",
            "materials", "method", "data collection",
        ],
        "keywords": [
            "dataset", "data source", "sample", "participants", "respondents",
            "observations", "records", "responses", "collected", "retained",
            "final sample", "training data", "test data",
        ],
        "excluded_sections": ["references", "appendix"],
    },
    "models": {
        "preferred_sections": [
            "model", "method", "methodology", "architecture", "framework",
            "algorithm", "implementation",
        ],
        "keywords": [
            "model", "algorithm", "architecture", "framework",
            "classifier", "regression", "neural network", "transformer",
            "cnn", "rnn", "svm", "random forest", "xgboost",
        ],
        "excluded_sections": ["references", "appendix"],
    },
    "results": {
        "preferred_sections": [
            "results", "findings", "analysis", "evaluation",
            "results and discussion",
        ],
        "keywords": [
            "result", "finding", "significant", "supported", "hypothesis",
            "effect", "accuracy", "precision", "recall", "f1", "auc",
            "anova", "regression", "mediation", "moderation",
            "confidence interval", "p <", "p=", "β", "r²",
        ],
        "excluded_sections": ["references", "appendix"],
    },
    "limitations": {
        "preferred_sections": [
            "limitations", "limitation", "discussion", "general discussion",
            "conclusion", "future research", "future work",
        ],
        "keywords": [
            "limitation", "limitations", "limited", "restrict",
            "generalizability", "generalisability", "generalization",
            "generalisation", "self-reported", "self reported",
            "single country", "cross-cultural", "cross cultural",
            "ecological validity", "scenario-based", "scenario based",
            "did not account", "not measured", "not directly measured",
            "future research should", "future studies should",
            "small sample", "convenience sampling", "snowball",
        ],
        "excluded_sections": ["references", "appendix", "acknowledgement"],
    },
    "future_work": {
        "preferred_sections": [
            "future research", "future work", "limitations",
            "discussion", "conclusion", "recommendations",
        ],
        "keywords": [
            "future research", "future work", "future studies",
            "further research", "should examine", "should explore",
            "could examine", "could explore", "recommend",
        ],
        "excluded_sections": ["references", "appendix"],
    },
    "literature_review": {
        "preferred_sections": [
            "literature review", "related work", "background",
            "theoretical background", "prior research",
        ],
        "keywords": [
            "previous research", "prior research", "prior studies",
            "literature", "scholars", "existing studies",
        ],
        "excluded_sections": ["references", "appendix"],
    },
    "question_answering": {
        "preferred_sections": [],
        "keywords": [],
        "excluded_sections": ["references", "appendix"],
    },
}


TASK_QUERY_EXPANSIONS = {
    "methodology": (
        "methodology research design study design participants sample sampling "
        "procedure data collection questionnaire survey interview measurement "
        "analysis experiment qualitative quantitative mixed methods"
    ),
    "datasets": (
        "dataset data source sample participants respondents observations "
        "records responses training test data"
    ),
    "models": (
        "model algorithm architecture framework classifier method implementation"
    ),
    "results": (
        "results findings outcome effect significant hypothesis evaluation analysis"
    ),
    "limitations": (
        "limitations weaknesses constraints drawbacks restricted generalizability "
        "generalisability sampling bias self-reported single country cross-cultural "
        "ecological validity scenario-based not measured did not account future research"
    ),
    "future_work": (
        "future research future work future studies recommendations further research "
        "should examine should explore"
    ),
    "literature_review": (
        "literature review prior research previous studies related work theoretical background"
    ),
    "question_answering": "",
}

