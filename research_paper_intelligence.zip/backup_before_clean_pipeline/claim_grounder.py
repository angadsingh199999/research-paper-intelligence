import re
from collections import defaultdict

from app.models.schemas import GroundedClaim, GroundedClaims, Citation


_ABBREVIATIONS = (
    "et al.", "e.g.", "i.e.", "cf.", "vs.", "etc.", "fig.", "eq.",
    "approx.", "dr.", "prof.", "mr.", "mrs.", "ms.", "no.",
)
_PLACEHOLDER = "\uE000"


class ClaimGrounder:
    """
    Evidence-to-claim conversion.

    Important design rule:
    - claims are extracted from retrieved evidence;
    - numeric values are never invented or "corrected";
    - paper/chunk/page provenance is attached immediately;
    - comparison queries preserve claims from every represented paper.
    """

    TASK_TERMS = {
        "methodology": (
            "method", "methodology", "research design", "experimental design",
            "participant", "sample", "sampling", "questionnaire", "survey",
            "interview", "data collection", "procedure", "measurement",
            "likert", "random", "experiment", "qualitative", "quantitative",
            "mixed-method", "mixed methods", "analysis",
        ),
        "datasets": (
            "dataset", "data source", "sample", "participant", "respondent",
            "response", "record", "observation", "collected", "retained",
        ),
        "models": (
            "model", "algorithm", "architecture", "framework", "classifier",
            "regression", "neural", "transformer", "cnn", "svm",
        ),
        "results": (
            "result", "finding", "significant", "supported", "hypothesis",
            "effect", "accuracy", "precision", "recall", "f1", "auc",
            "anova", "regression", "mediation", "moderation", "confidence interval",
        ),
        "limitations": (
            "limitation", "limited", "restrict", "generalizability",
            "generalisability", "generalization", "generalisation",
            "self-reported", "self reported", "single country",
            "cross-cultural", "cross cultural", "ecological validity",
            "scenario-based", "scenario based", "did not account",
            "not measured", "not directly measured", "small sample",
            "convenience sampling", "snowball",
        ),
        "future_work": (
            "future research", "future work", "future studies", "further research",
            "should examine", "should explore", "could examine", "could explore",
            "recommend",
        ),
        "literature_review": (
            "previous research", "prior research", "prior studies",
            "literature", "related work", "existing studies",
        ),
    }

    LIMITATION_SECTION_TERMS = (
        "limitation", "discussion", "conclusion", "future research",
        "future work", "recommendation",
    )

    LIMITATION_EXPLICIT_CUES = (
        "limitation", "limited", "limits ", "restrict", "generalizability",
        "generalisability", "generalization", "generalisation",
        "self-reported", "self reported", "single country", "cross-cultural",
        "cross cultural", "ecological validity", "scenario-based",
        "scenario based", "did not account", "did not measure", "not measured",
        "not directly measured", "cannot be generalized", "cannot be generalised",
        "future research should", "future studies should", "future work should",
    )

    NOISE_PATTERNS = (
        "copyright", "all rights reserved", "downloaded from", "publisher",
        "declaration of competing interest", "credit authorship", "funding",
        "appendix", "references",
    )

    def __init__(self):
        print("Claim grounding pipeline ready.")

    def ground(
        self,
        evidence,
        task=None,
        instruction=None,
        answer=None,
    ):
        if not evidence:
            return GroundedClaims(claims=[])

        task = str(task or "question_answering").lower().strip()
        question = str(instruction or answer or "").strip()

        grouped = defaultdict(list)
        for item in evidence:
            paper_id = str(item.get("paper_id", "") or "unknown")
            grouped[paper_id].append(item)

        # Extract within each paper first. This prevents paper 1 from using
        # the whole global claim budget before later papers are examined.
        per_paper = {}
        for paper_id, items in grouped.items():
            per_paper[paper_id] = self._extract_for_paper(
                items,
                task=task,
                question=question,
            )

        # Round-robin merge preserves coverage while still keeping each
        # paper's internal relevance order.
        merged = []
        max_len = max((len(v) for v in per_paper.values()), default=0)
        for index in range(max_len):
            for paper_id in sorted(per_paper):
                claims = per_paper[paper_id]
                if index < len(claims):
                    merged.append(claims[index])

        # A larger budget supports useful real-world answers but remains
        # bounded so synthesis does not become an evidence dump.
        total_cap = max(12, min(40, len(grouped) * 5))
        return GroundedClaims(claims=merged[:total_cap])

    def _extract_for_paper(self, evidence, task, question):
        candidates = []
        seen = set()

        for item in evidence:
            text = self._clean_text(item.get("text", ""))
            if not text:
                continue

            section = str(item.get("section", "")).lower().strip()

            for sentence in self._extract_sentences(text):
                sentence = self._clean_sentence(sentence)
                if len(sentence) < 28:
                    continue
                if self._is_noise(sentence):
                    continue

                score = self._sentence_score(
                    sentence=sentence,
                    section=section,
                    task=task,
                    question=question,
                )

                if score <= 0:
                    continue

                key = self._dedupe_key(sentence)
                if key in seen:
                    continue
                seen.add(key)

                candidates.append(
                    (score, len(sentence), sentence, item)
                )

        candidates.sort(
            key=lambda x: (x[0], -x[1]),
            reverse=True,
        )

        # 5 claims per paper provides enough context for richer answers.
        result = []
        for _, _, sentence, item in candidates[:5]:
            result.append(self._make_claim(sentence, item))
        return result

    def _sentence_score(self, sentence, section, task, question):
        lower = sentence.lower()
        score = 0.0

        # Strong query-specific relevance. This is what allows the fallback
        # QA path to work for questions outside the predefined task labels.
        q_terms = self._important_tokens(question)
        s_terms = self._important_tokens(sentence)
        if q_terms:
            overlap = len(q_terms & s_terms)
            score += overlap * 2.5

        task_terms = self.TASK_TERMS.get(task, ())
        task_hits = sum(term in lower for term in task_terms)
        score += min(task_hits, 8) * 1.5

        if task == "limitations":
            in_limitation_section = any(
                term in section for term in self.LIMITATION_SECTION_TERMS
            )
            explicit = any(
                cue in lower for cue in self.LIMITATION_EXPLICIT_CUES
            )

            # For "reported limitations", do not turn ordinary methodology
            # justifications into limitations merely because they contain
            # words such as "sampling" or "generalizability".
            if in_limitation_section:
                score += 7.0
            if explicit:
                score += 8.0
            if not in_limitation_section and not explicit:
                return -1.0

        elif task == "methodology":
            if any(
                x in section
                for x in (
                    "method", "design", "participant", "sample",
                    "procedure", "data collection", "measure",
                )
            ):
                score += 6.0
            if any(
                x in section
                for x in (
                    "reference", "future", "limitation", "conclusion",
                    "literature", "introduction",
                )
            ):
                score -= 8.0

        elif task == "results":
            if "result" in section or "finding" in section or "analysis" in section:
                score += 6.0

        elif task == "future_work":
            if "future" in section or "recommend" in section or "limitation" in section:
                score += 6.0

        elif task == "literature_review":
            if "literature" in section or "background" in section or "related" in section:
                score += 6.0

        # Generic QA: if task vocabulary gives no signal, query overlap is
        # sufficient. If the question is empty, keep informative sentences.
        if task == "question_answering":
            if q_terms and not (q_terms & s_terms):
                return -1.0
            score += min(len(s_terms), 12) * 0.1

        return score

    def _citation(self, item):
        return Citation(
            paper_id=str(item.get("paper_id", "")),
            paper_title=str(item.get("paper_title", "")),
            page_start=int(item.get("page_start", 0) or 0),
            page_end=int(item.get("page_end", 0) or 0),
            section=str(item.get("section", "")),
            chunk_id=str(item.get("chunk_id", "")),
        )

    def _make_claim(self, text, item):
        chunk_id = str(item.get("chunk_id", ""))
        return GroundedClaim(
            claim=text,
            evidence_ids=[chunk_id] if chunk_id else [],
            citations=[self._citation(item)],
        )

    @staticmethod
    def _important_tokens(text):
        stop = {
            "what", "which", "who", "when", "where", "why", "how",
            "the", "a", "an", "and", "or", "of", "to", "in", "on",
            "for", "with", "from", "by", "is", "are", "was", "were",
            "be", "been", "being", "did", "does", "do", "used", "use",
            "paper", "papers", "study", "studies", "research", "researchers",
            "both", "all", "each", "compare", "comparison",
        }
        return {
            token
            for token in re.findall(r"[a-z0-9]+", str(text).lower())
            if len(token) >= 3 and token not in stop
        }

    def _is_noise(self, sentence):
        lower = sentence.lower()
        return any(pattern in lower for pattern in self.NOISE_PATTERNS)

    @staticmethod
    def _clean_text(text):
        text = str(text or "")
        text = text.replace("\u00ad", "")
        text = text.replace("\u00a0", " ")
        text = re.sub(r"(\w)-\s+(\w)", r"\1\2", text)
        text = re.sub(r"\s+", " ", text)
        return text.strip()

    @staticmethod
    def _clean_sentence(sentence):
        sentence = re.sub(r"\s+", " ", str(sentence or "")).strip()

        # Remove obvious journal running-header fragments only when they
        # appear at the very end. Do not alter scientific numeric values.
        sentence = re.sub(
            r"\s+[A-Z]{2,8}\s+\d{1,3}(?:,\d{1,3})?\s+\d{1,4}$",
            "",
            sentence,
        )
        return sentence.strip()

    @staticmethod
    def _dedupe_key(sentence):
        return re.sub(r"\W+", " ", sentence.lower()).strip()

    def _extract_sentences(self, text):
        if not text:
            return []

        protected = str(text)
        for abbr in _ABBREVIATIONS:
            protected = re.sub(
                re.escape(abbr),
                abbr.replace(".", _PLACEHOLDER),
                protected,
                flags=re.IGNORECASE,
            )

        # Protect decimal points inside numbers.
        protected = re.sub(
            r"(?<=\d)\.(?=\d)",
            _PLACEHOLDER,
            protected,
        )

        pieces = re.split(r"(?<=[.!?])\s+", protected)
        result = []
        for piece in pieces:
            piece = piece.replace(_PLACEHOLDER, ".").strip()
            if len(piece) > 10:
                result.append(piece)
        return result

