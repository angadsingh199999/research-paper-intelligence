import re
from collections import defaultdict
from typing import Any, Dict


class GroundedAnswerSynthesizer:
    """
    Clean deterministic synthesis from grounded claims.

    This layer deliberately does not invent new facts. It produces a richer,
    readable answer while preserving paper boundaries and source wording.
    """

    def __init__(self, max_claims=40, max_evidence=20):
        self.max_claims = int(max_claims)
        self.max_evidence = int(max_evidence)

    def synthesize(
        self,
        question: str,
        task: str,
        grounded_claims=None,
        evidence=None,
    ) -> Dict[str, Any]:
        question = str(question or "").strip()
        task = str(task or "question_answering").lower().strip()
        claims = list(grounded_claims or [])[: self.max_claims]
        evidence = list(evidence or [])

        if not claims:
            answer = (
                "The available papers do not contain enough grounded evidence "
                "to answer this question reliably."
            )
        elif self._is_comparison_question(question):
            answer = self._compose_comparison(question, task, claims)
        else:
            answer = self._compose_standard(question, task, claims)

        return {
            "answer": answer.strip(),
            "task": task,
            "claim_count": len(claims),
            "evidence_count": min(len(evidence), self.max_evidence),
        }

    def _compose_standard(self, question, task, claims):
        texts = self._dedupe_texts(
            [self._claim_text(c) for c in claims if self._claim_text(c)]
        )

        if not texts:
            return (
                "The available evidence does not contain enough grounded "
                "information to answer this question reliably."
            )

        intro = {
            "methodology": "The methodology reported in the retrieved evidence is as follows:",
            "datasets": "The papers report the following data, sample, or dataset information:",
            "models": "The following models, algorithms, or analytical approaches are reported:",
            "results": "The main grounded results relevant to the question are:",
            "limitations": "The authors report the following limitations:",
            "future_work": "The papers suggest the following future research directions:",
            "literature_review": "The relevant literature and prior-research points are:",
            "question_answering": "Based on the retrieved evidence:",
        }.get(task, "Based on the retrieved evidence:")

        lines = [intro, ""]
        for text in texts[:10]:
            lines.append(f"- {self._polish(text)}")

        if len(texts) > 10:
            lines.extend([
                "",
                f"The answer above summarizes the 10 strongest grounded points "
                f"from {len(texts)} relevant claims.",
            ])

        return "\n".join(lines)

    def _compose_comparison(self, question, task, claims):
        grouped = defaultdict(list)
        paper_titles = {}

        for claim in claims:
            paper_id = self._claim_paper_id(claim) or "unknown"
            grouped[paper_id].append(self._claim_text(claim))
            title = self._claim_paper_title(claim)
            if title:
                paper_titles[paper_id] = title

        grouped = {
            pid: self._dedupe_texts([t for t in texts if t])
            for pid, texts in grouped.items()
        }

        if len(grouped) < 2:
            only_id = next(iter(grouped), "unknown")
            label = self._paper_label(only_id, paper_titles.get(only_id))
            lines = [
                (
                    "A reliable cross-paper comparison cannot yet be made "
                    "because only one paper contributed grounded evidence "
                    "for this question."
                ),
                "",
                f"{label}:",
            ]
            for text in grouped.get(only_id, [])[:8]:
                lines.append(f"- {self._polish(text)}")
            return "\n".join(lines)

        wants_shared = self._asks_for_shared(question)

        lines = []

        if wants_shared:
            common = self._find_common_concepts(task, grouped)
            lines.append("Shared points supported across the papers:")
            lines.append("")
            if common:
                for item in common:
                    lines.append(f"- {item}")
            else:
                lines.append(
                    "- No specific point could be established as common to "
                    "every represented paper from the grounded evidence."
                )
            lines.append("")

        lines.append("Paper-by-paper evidence:")
        lines.append("")

        for paper_id in sorted(grouped):
            label = self._paper_label(
                paper_id,
                paper_titles.get(paper_id),
            )
            lines.append(f"{label}")
            for text in grouped[paper_id][:6]:
                lines.append(f"- {self._polish(text)}")
            lines.append("")

        if not wants_shared:
            similarities = self._find_common_concepts(task, grouped)
            if similarities:
                lines.append("Main similarities:")
                lines.append("")
                for item in similarities:
                    lines.append(f"- {item}")
                lines.append("")

        lines.append(
            "The comparison above includes only claims that were grounded "
            "in retrieved evidence; unsupported differences are not inferred."
        )
        return "\n".join(lines).strip()

    def _find_common_concepts(self, task, grouped):
        """
        Conservative concept intersection.

        A concept is reported as common only if at least one claim from every
        represented paper matches that concept.
        """
        concept_map = self._concept_map(task)
        if not concept_map:
            return []

        per_paper = {}
        for paper_id, texts in grouped.items():
            concepts = set()
            joined = " ".join(texts).lower()
            for name, terms in concept_map.items():
                if any(term in joined for term in terms):
                    concepts.add(name)
            per_paper[paper_id] = concepts

        shared = None
        for concepts in per_paper.values():
            shared = set(concepts) if shared is None else shared & concepts

        shared = shared or set()

        descriptions = {
            "generalizability": (
                "The papers identify limits to generalizability, such as "
                "restricted sampling, geography, or population coverage."
            ),
            "self_report": (
                "The papers rely on self-reported or participant-reported "
                "measures, which the authors identify as a limitation."
            ),
            "realism": (
                "The papers note limits related to realism or ecological "
                "validity and call for more realistic or actual-use settings."
            ),
            "sampling": (
                "Sampling or sample composition is identified as a constraint "
                "that can limit how broadly the findings apply."
            ),
            "longitudinal": (
                "The papers indicate that longer-term or longitudinal evidence "
                "is still needed."
            ),
            "research_design": (
                "The papers describe an explicit research/study design."
            ),
            "questionnaire": (
                "The papers use questionnaire or survey-based data collection."
            ),
            "interviews": (
                "The papers use interviews as part of the data collection."
            ),
            "participants": (
                "The papers report participant or sample information."
            ),
            "experimental": (
                "The papers use an experimental component in their research design."
            ),
            "significant_effects": (
                "The papers report statistically evaluated effects or relationships."
            ),
        }

        return [
            descriptions[name]
            for name in sorted(shared)
            if name in descriptions
        ]

    @staticmethod
    def _concept_map(task):
        if task == "limitations":
            return {
                "generalizability": (
                    "generalizability", "generalisability", "generalization",
                    "generalisation", "cross-cultural", "cross cultural",
                    "single country", "geographic", "broader sample",
                ),
                "self_report": (
                    "self-reported", "self reported", "behavioral intentions",
                    "behavioural intentions",
                ),
                "realism": (
                    "ecological validity", "scenario-based", "scenario based",
                    "actual interaction", "actual use", "real usage",
                    "working vto", "live or interactive",
                ),
                "sampling": (
                    "convenience sampling", "snowball", "sample was composed",
                    "sample composition", "small sample", "sampling frame",
                ),
                "longitudinal": (
                    "longitudinal", "long-term", "long term", "over time",
                ),
            }

        if task == "methodology":
            return {
                "research_design": (
                    "research design", "study design", "methodology",
                    "between-subjects", "mixed-method", "mixed methods",
                ),
                "questionnaire": ("questionnaire", "survey"),
                "interviews": ("interview", "semi-structured"),
                "participants": ("participant", "sample", "respondent"),
                "experimental": ("experiment", "experimental", "randomly assigned"),
            }

        if task == "results":
            return {
                "significant_effects": (
                    "significant", "effect", "supported", "regression",
                    "anova", "mediation", "moderation",
                ),
            }

        return {}

    @staticmethod
    def _claim_text(claim):
        if isinstance(claim, dict):
            return str(claim.get("claim") or claim.get("text") or "").strip()
        return str(
            getattr(claim, "claim", None)
            or getattr(claim, "text", None)
            or ""
        ).strip()

    @staticmethod
    def _claim_paper_id(claim):
        if isinstance(claim, dict):
            direct = claim.get("paper_id")
            citations = claim.get("citations", [])
            evidence_ids = claim.get("evidence_ids", [])
        else:
            direct = getattr(claim, "paper_id", None)
            citations = getattr(claim, "citations", [])
            evidence_ids = getattr(claim, "evidence_ids", [])

        if direct:
            return str(direct)

        if citations:
            first = citations[0]
            value = first.get("paper_id") if isinstance(first, dict) else getattr(first, "paper_id", None)
            if value:
                return str(value)

        for evidence_id in evidence_ids or []:
            value = str(evidence_id)
            if "_chunk_" in value:
                return value.split("_chunk_", 1)[0]
        return None

    @staticmethod
    def _claim_paper_title(claim):
        citations = (
            claim.get("citations", [])
            if isinstance(claim, dict)
            else getattr(claim, "citations", [])
        )
        if not citations:
            return ""
        first = citations[0]
        return str(
            first.get("paper_title", "")
            if isinstance(first, dict)
            else getattr(first, "paper_title", "")
        ).strip()

    @staticmethod
    def _paper_label(paper_id, title=None):
        title = str(title or "").strip()
        pid = str(paper_id or "").strip()

        # If metadata contains a real title, use it.
        if title and title.lower() not in {pid.lower(), f"{pid}.pdf".lower()}:
            return title

        match = re.fullmatch(r"paper\s*(\d+)", pid, flags=re.IGNORECASE)
        if match:
            return f"Paper {match.group(1)}"

        return pid or "Unidentified paper"

    @staticmethod
    def _is_comparison_question(question):
        q = str(question or "").lower()
        terms = (
            "compare", "comparison", "comparative", "difference",
            "differences", "similarity", "similarities", "both papers",
            "both studies", "all papers", "all the papers", "each paper",
            "across papers", "across studies", "between papers",
            "between studies", "in common", "shared",
        )
        return any(term in q for term in terms)

    @staticmethod
    def _asks_for_shared(question):
        q = str(question or "").lower()
        terms = (
            "both papers", "both studies", "in common", "common",
            "shared", "similarities", "same limitation", "same limitations",
        )
        return any(term in q for term in terms)

    @staticmethod
    def _dedupe_texts(texts):
        result = []
        seen = set()
        for text in texts:
            key = re.sub(r"\W+", " ", str(text).lower()).strip()
            if not key or key in seen:
                continue
            seen.add(key)
            result.append(str(text).strip())
        return result

    @staticmethod
    def _polish(text):
        text = re.sub(r"\s+", " ", str(text or "")).strip()
        if not text:
            return text

        # Remove standalone enumeration words that become awkward after
        # sentence extraction ("First,", "Fourth,", etc.).
        text = re.sub(
            r"^(first|second|third|fourth|fifth|sixth|finally|additionally|in addition),?\s+",
            "",
            text,
            flags=re.IGNORECASE,
        )

        if text and text[-1] not in ".!?":
            text += "."
        return text[0].upper() + text[1:] if text else text

