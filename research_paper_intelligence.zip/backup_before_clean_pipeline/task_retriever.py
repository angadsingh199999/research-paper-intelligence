from app.retrieval.section_rules import TASK_SECTION_RULES
from app.retrieval.reranker import Reranker


class TaskSpecificRetriever:
    """
    Task-aware retrieval layer.

    The hybrid retriever supplies broad lexical + semantic candidates.
    This layer adds section/task relevance and then reranks the candidates
    with the cross-encoder.
    """

    def __init__(
        self,
        hybrid_retriever,
        reranker=None,
        candidate_k=24,
        top_k=8,
    ):
        self.hybrid_retriever = hybrid_retriever
        self.reranker = reranker if reranker is not None else Reranker()
        self.candidate_k = int(candidate_k)
        self.top_k = int(top_k)

        # Expose chunks when the underlying BM25 retriever has them.
        self.chunks = self._discover_chunks()

    def _discover_chunks(self):
        candidates = [
            self.hybrid_retriever,
            getattr(self.hybrid_retriever, "bm25_retriever", None),
            getattr(self.hybrid_retriever, "bm25", None),
        ]
        for obj in candidates:
            chunks = getattr(obj, "chunks", None)
            if chunks:
                return list(chunks)
        return []

    def search(self, query, task=None, top_k=None):
        query = str(query or "").strip()
        if not query:
            return []

        final_k = int(top_k) if top_k is not None else self.top_k
        candidate_k = max(self.candidate_k, final_k * 3)

        candidates = self.hybrid_retriever.search(
            query,
            top_k=candidate_k,
        )

        if not candidates:
            return []

        normalized = [self._normalize_result(item) for item in candidates]
        normalized = [item for item in normalized if item.get("chunk_id")]

        if task:
            normalized = self._apply_task_score(normalized, task)

        try:
            reranked = self.reranker.rerank(
                query=query,
                results=normalized,
                top_k=min(len(normalized), max(final_k * 2, final_k)),
            )
        except Exception:
            reranked = normalized

        reranked.sort(
            key=lambda item: (
                float(item.get("combined_score", 0.0)),
                float(item.get("task_score", 0.0)),
                float(item.get("rrf_score", 0.0)),
            ),
            reverse=True,
        )

        return reranked[:final_k]

    def retrieve(self, query, task=None, top_k=None):
        return self.search(query=query, task=task, top_k=top_k)

    def run(self, query, task=None, top_k=None):
        return self.search(query=query, task=task, top_k=top_k)

    @staticmethod
    def _normalize_result(result):
        item = dict(result)

        metadata = item.get("metadata") or {}
        if isinstance(metadata, dict):
            for key in (
                "paper_id", "paper_title", "section",
                "page_start", "page_end", "word_count",
            ):
                if not item.get(key) and metadata.get(key) is not None:
                    item[key] = metadata.get(key)

        item.setdefault("paper_id", "")
        item.setdefault("paper_title", "")
        item.setdefault("section", "")
        item.setdefault("page_start", 0)
        item.setdefault("page_end", 0)
        item.setdefault("text", "")
        item.setdefault("rrf_score", 0.0)
        item.setdefault("score", 0.0)
        return item

    def _apply_task_score(self, results, task):
        task = str(task or "question_answering").lower().strip()
        rules = TASK_SECTION_RULES.get(
            task,
            TASK_SECTION_RULES["question_answering"],
        )

        preferred_sections = [
            str(x).lower().strip()
            for x in rules.get("preferred_sections", [])
        ]
        keywords = [
            str(x).lower().strip()
            for x in rules.get("keywords", [])
        ]
        excluded_sections = [
            str(x).lower().strip()
            for x in rules.get("excluded_sections", [])
        ]

        scored = []

        for result in results:
            item = self._normalize_result(result)
            section = str(item.get("section", "")).lower().strip()
            text = str(item.get("text", "")).lower()

            task_score = 0.0

            if any(x and x in section for x in excluded_sections):
                task_score -= 25.0

            if preferred_sections:
                for preferred in preferred_sections:
                    if preferred and preferred in section:
                        task_score += 8.0

            # Cap repeated keyword influence so a very long chunk does not
            # dominate only because it repeats the same task vocabulary.
            keyword_hits = 0
            for keyword in keywords:
                if keyword and keyword in text:
                    keyword_hits += 1
            task_score += min(keyword_hits, 12) * 1.25

            # General research-material guard.
            if section == "references":
                task_score -= 100.0
            elif section == "appendix":
                task_score -= 50.0

            item["task_score"] = float(task_score)

            # Preserve the reranker's combined score when present. If not,
            # create a stable combined score that keeps RRF + task relevance.
            if "combined_score" not in item:
                item["combined_score"] = (
                    float(item.get("rrf_score", 0.0)) * 100.0
                    + float(task_score)
                )

            scored.append(item)

        scored.sort(
            key=lambda item: (
                float(item.get("task_score", 0.0)),
                float(item.get("rrf_score", 0.0)),
            ),
            reverse=True,
        )
        return scored

