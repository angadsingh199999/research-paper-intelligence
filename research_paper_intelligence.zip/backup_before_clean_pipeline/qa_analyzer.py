from collections import defaultdict

from app.analysis.task_router import TaskRouter
from app.analysis.claim_grounder import ClaimGrounder
from app.analysis.claim_relevance_validator import ClaimRelevanceValidator
from app.analysis.answer_synthesizer import GroundedAnswerSynthesizer
from app.analysis.citation_generator import CitationGenerator
from app.analysis.hallucination_detector import HallucinationDetector
from app.analysis.confidence_scorer import ConfidenceScorer
from app.retrieval.bm25_retriever import BM25Retriever
from app.retrieval.section_rules import TASK_QUERY_EXPANSIONS, TASK_SECTION_RULES


class QAAnalyzer:
    """
    Reliable orchestration for single-paper and multi-paper QA.

    It supports known research tasks and a general QA fallback. Comparison
    questions use explicit per-paper retrieval so one paper cannot dominate
    merely because its chunks rank higher globally.
    """

    def __init__(
        self,
        task_retriever,
        claim_grounder=None,
        claim_relevance_validator=None,
        task_router=None,
        answer_synthesizer=None,
        citation_generator=None,
        hallucination_detector=None,
        confidence_scorer=None,
    ):
        self.task_retriever = task_retriever
        self.claim_grounder = claim_grounder or ClaimGrounder()
        self.claim_relevance_validator = (
            claim_relevance_validator or ClaimRelevanceValidator()
        )
        self.task_router = task_router or TaskRouter()
        self.answer_synthesizer = (
            answer_synthesizer or GroundedAnswerSynthesizer()
        )
        self.citation_generator = citation_generator or CitationGenerator()
        self.hallucination_detector = (
            hallucination_detector or HallucinationDetector()
        )
        self.confidence_scorer = confidence_scorer or ConfidenceScorer()

    def answer(self, question, task=None):
        question = str(question or "").strip()
        if not question:
            return self._empty_result(
                answer="Please provide a research question.",
                task=task or "question_answering",
            )

        if task is None:
            task, task_scores = self._detect_task(question)
        else:
            task = str(task).lower().strip()
            task_scores = {task: 1}

        print(f"Detected task: {task}")

        evidence = self._retrieve(question, task)
        if not evidence:
            return self._empty_result(
                answer=(
                    "The available papers do not contain sufficient retrieved "
                    "evidence to answer this question reliably."
                ),
                task=task,
                task_scores=task_scores,
            )

        self._print_evidence(evidence, task)

        print("\nGrounding retrieved evidence...")
        grounded = self.claim_grounder.ground(
            evidence=evidence,
            task=task,
            instruction=question,
        )
        grounded_claims = list(getattr(grounded, "claims", []) or [])
        print("Grounded claims:", len(grounded_claims))

        if not grounded_claims:
            return self._empty_result(
                answer=(
                    "Relevant passages were retrieved, but no sufficiently "
                    "grounded claim could be extracted for this question."
                ),
                task=task,
                task_scores=task_scores,
                evidence=evidence,
            )

        relevant_claims = self._select_relevant_claims(
            question=question,
            claims=grounded_claims,
            evidence=evidence,
            comparison=self._is_comparison_question(question),
        )

        print("Relevant grounded claims:", len(relevant_claims))
        print(
            "Papers represented in final claims:",
            sorted(self._claim_paper_ids(relevant_claims, evidence)),
        )

        print("\nSynthesizing grounded answer...")
        synthesis = self.answer_synthesizer.synthesize(
            question=question,
            task=task,
            grounded_claims=relevant_claims,
            evidence=evidence,
        )
        answer_text = str(synthesis.get("answer", "")).strip()
        if not answer_text:
            answer_text = (
                "The available evidence does not contain enough grounded "
                "information to answer this question reliably."
            )

        print("\nChecking grounded claims for support...")
        try:
            hallucination_result = self.hallucination_detector.verify(
                answer=self._build_claim_verification_text(relevant_claims),
                evidence=evidence,
            )
        except Exception as exc:
            print("Hallucination detection failed:", exc)
            hallucination_result = {
                "answer": answer_text,
                "supported": False,
                "hallucination_detected": False,
                "support_score": 0.0,
                "claims": [],
            }

        print("\nGenerating citations and source attribution...")
        try:
            citation_result = self.citation_generator.generate(
                claims=relevant_claims,
                evidence=evidence,
            )
        except Exception as exc:
            print("Citation generation failed:", exc)
            citation_result = {
                "claim_citations": [],
                "sources": [],
                "source_count": 0,
            }

        claim_citations = citation_result.get("claim_citations", [])
        sources = citation_result.get("sources", [])

        print("\nCalculating answer confidence...")
        try:
            confidence_result = self.confidence_scorer.score(
                claims=relevant_claims,
                evidence=evidence,
                citations=claim_citations,
                hallucination=hallucination_result,
            )
        except Exception as exc:
            print("Confidence scoring failed:", exc)
            confidence_result = {
                "score": 0.0,
                "label": "LOW",
                "reason": "Confidence scoring failed.",
            }

        if not isinstance(confidence_result, dict):
            confidence_result = {
                "score": 0.0,
                "label": "LOW",
                "reason": "Invalid confidence scorer output.",
            }

        if self._is_comparison_question(question):
            self._apply_comparison_coverage(
                confidence_result,
                relevant_claims,
                evidence,
            )

        return {
            "answer": answer_text,
            "task": task,
            "claims": relevant_claims,
            "evidence": self._build_evidence_output(evidence),
            "task_scores": task_scores,
            "hallucination": hallucination_result,
            "citations": claim_citations,
            "sources": sources,
            "confidence": confidence_result,
        }

    # ============================================================
    # TASK DETECTION
    # ============================================================

    def _detect_task(self, question):
        try:
            result = self.task_router.route(question)
            if isinstance(result, tuple):
                return result
            if isinstance(result, dict):
                return (
                    result.get("task", "question_answering"),
                    result.get("task_scores", {}),
                )
        except Exception as exc:
            print("TaskRouter fallback:", exc)

        q = str(question).lower()
        keyword_groups = {
            "methodology": (
                "methodology", "method", "research design", "procedure",
                "data collection", "sampling", "how was the study conducted",
            ),
            "datasets": (
                "dataset", "data source", "sample", "participants", "respondents",
            ),
            "models": (
                "model", "algorithm", "architecture", "framework",
            ),
            "results": (
                "result", "results", "finding", "findings", "hypothesis",
                "significant", "effect",
            ),
            "limitations": (
                "limitation", "limitations", "weakness", "weaknesses",
                "generalizability", "generalisability",
            ),
            "future_work": (
                "future research", "future work", "future studies",
                "further research", "recommendation",
            ),
            "literature_review": (
                "literature", "related work", "previous research",
                "prior research", "background",
            ),
        }

        scores = {
            task: sum(term in q for term in terms)
            for task, terms in keyword_groups.items()
        }

        best = max(scores, key=scores.get)
        if scores[best] == 0:
            return "question_answering", scores
        return best, scores

    # ============================================================
    # RETRIEVAL
    # ============================================================

    def _retrieve(self, question, task):
        if self._is_comparison_question(question):
            per_paper = self._retrieve_per_paper(question, task)
            if per_paper:
                return per_paper

        results = self.task_retriever.search(
            query=question,
            task=task,
            top_k=12,
        )
        return self._filter_task_evidence(results, task)

    def _retrieve_per_paper(self, question, task):
        chunks = self._get_available_chunks()
        if not chunks:
            return []

        grouped = defaultdict(list)
        for chunk in chunks:
            paper_id = (
                chunk.get("paper_id")
                if isinstance(chunk, dict)
                else getattr(chunk, "paper_id", None)
            )
            if paper_id:
                grouped[str(paper_id)].append(chunk)

        if not grouped:
            return []

        print("Comparison query detected: retrieving evidence per paper.")
        print("Papers available for comparison:", sorted(grouped))

        task_name = str(task or "question_answering").lower().strip()
        expansion = TASK_QUERY_EXPANSIONS.get(task_name, "")
        local_query = f"{question} {expansion}".strip()

        per_paper_limit = 5 if len(grouped) <= 4 else 3
        merged = {}

        reranker = getattr(self.task_retriever, "reranker", None)

        for paper_id, paper_chunks in grouped.items():
            try:
                local_bm25 = BM25Retriever(paper_chunks)
                local = local_bm25.search(
                    local_query,
                    top_k=min(
                        len(paper_chunks),
                        max(10, per_paper_limit * 3),
                    ),
                )

                if hasattr(self.task_retriever, "_apply_task_score"):
                    local = self.task_retriever._apply_task_score(
                        local,
                        task_name,
                    )

                local = self._filter_task_evidence(local, task_name)

                if reranker is not None and local:
                    try:
                        local = reranker.rerank(
                            query=question,
                            results=local,
                            top_k=min(len(local), per_paper_limit * 2),
                        )
                    except Exception:
                        pass

                # Filter once more after reranking and keep several chunks.
                local = self._filter_task_evidence(local, task_name)
                selected = local[:per_paper_limit]

                for item in selected:
                    item = dict(item)
                    item["paper_id"] = item.get("paper_id") or paper_id
                    chunk_id = item.get("chunk_id")
                    if chunk_id:
                        merged[chunk_id] = item

                print(f"  {paper_id}: {len(selected)} evidence chunk(s)")

            except Exception as exc:
                print(f"  {paper_id}: per-paper retrieval failed: {exc}")

        # Add globally strong candidates without removing per-paper coverage.
        try:
            global_results = self.task_retriever.search(
                query=question,
                task=task_name,
                top_k=min(16, len(chunks)),
            )
            global_results = self._filter_task_evidence(
                global_results,
                task_name,
            )
            for item in global_results:
                chunk_id = item.get("chunk_id")
                if chunk_id and chunk_id not in merged:
                    merged[chunk_id] = item
        except Exception:
            pass

        results = list(merged.values())

        # Build final evidence by round-robin paper coverage, then fill with
        # globally strongest remaining evidence.
        by_paper = defaultdict(list)
        for item in results:
            by_paper[str(item.get("paper_id", ""))].append(item)

        for items in by_paper.values():
            items.sort(
                key=lambda x: (
                    float(x.get("combined_score", 0.0)),
                    float(x.get("task_score", 0.0)),
                    float(x.get("rrf_score", 0.0)),
                ),
                reverse=True,
            )

        covered = []
        used = set()
        for rank in range(per_paper_limit):
            for paper_id in sorted(grouped):
                items = by_paper.get(paper_id, [])
                if rank < len(items):
                    item = items[rank]
                    chunk_id = item.get("chunk_id")
                    if chunk_id not in used:
                        covered.append(item)
                        used.add(chunk_id)

        remaining = [
            item for item in results
            if item.get("chunk_id") not in used
        ]
        remaining.sort(
            key=lambda x: (
                float(x.get("combined_score", 0.0)),
                float(x.get("task_score", 0.0)),
            ),
            reverse=True,
        )

        max_evidence = min(40, max(16, len(grouped) * per_paper_limit))
        for item in remaining:
            if len(covered) >= max_evidence:
                break
            covered.append(item)

        return covered[:max_evidence]

    def _filter_task_evidence(self, results, task):
        if not results:
            return []

        task = str(task or "question_answering").lower().strip()
        rules = TASK_SECTION_RULES.get(
            task,
            TASK_SECTION_RULES["question_answering"],
        )

        excluded = tuple(
            str(x).lower()
            for x in rules.get("excluded_sections", [])
        )

        filtered = []
        for item in results:
            section = str(item.get("section", "")).lower().strip()
            text = str(item.get("text", "")).lower()

            if section == "references" or section == "appendix":
                continue
            if excluded and any(x in section for x in excluded):
                continue

            if task == "limitations":
                # Prefer explicit author-reported limitations/future-work
                # material. This removes methodological justification
                # sentences that only happen to contain "generalizability".
                strong_section = any(
                    x in section
                    for x in (
                        "limitation", "discussion", "conclusion",
                        "future research", "future work", "recommendation",
                    )
                )
                explicit = any(
                    x in text
                    for x in (
                        "limitation", "limits the", "limited by",
                        "generalizability", "generalisability",
                        "self-reported", "self reported",
                        "ecological validity", "scenario-based",
                        "did not account", "not directly measured",
                        "future research should", "future studies should",
                    )
                )
                if not strong_section and not explicit:
                    continue

            filtered.append(item)

        return filtered or list(results)

    # ============================================================
    # CLAIM SELECTION
    # ============================================================

    def _select_relevant_claims(
        self,
        question,
        claims,
        evidence,
        comparison=False,
    ):
        ranked = list(claims)

        try:
            validator = self.claim_relevance_validator
            if hasattr(validator, "score_claims"):
                scored = validator.score_claims(
                    question=question,
                    claims=claims,
                )
                ranked = [
                    item["claim"]
                    for item in scored
                    if isinstance(item, dict) and item.get("claim") is not None
                ]
            else:
                ranked = validator.filter_claims(
                    question=question,
                    claims=claims,
                    max_claims=max(12, len(claims)),
                )
        except Exception as exc:
            print("Claim relevance ranking failed:", exc)

        if not ranked:
            ranked = list(claims)

        ranked = self._dedupe_claims(ranked)

        if not comparison:
            return ranked[:10]

        paper_to_claims = defaultdict(list)
        for claim in ranked:
            paper_id = self._claim_paper_id(claim, evidence)
            if paper_id:
                paper_to_claims[paper_id].append(claim)

        if not paper_to_claims:
            return ranked[:12]

        # Up to four strong claims per paper. This produces substantial
        # comparisons without letting one paper dominate.
        final = []
        for rank in range(4):
            for paper_id in sorted(paper_to_claims):
                claims_for_paper = paper_to_claims[paper_id]
                if rank < len(claims_for_paper):
                    final.append(claims_for_paper[rank])

        # Allow a few extra globally strong claims after coverage.
        for claim in ranked:
            if len(final) >= min(40, len(paper_to_claims) * 5):
                break
            if claim not in final:
                final.append(claim)

        return self._dedupe_claims(final)

    @staticmethod
    def _dedupe_claims(claims):
        result = []
        seen = set()
        for claim in claims:
            text = (
                claim.get("claim") if isinstance(claim, dict)
                else getattr(claim, "claim", None)
            ) or (
                claim.get("text") if isinstance(claim, dict)
                else getattr(claim, "text", None)
            ) or str(claim)

            key = " ".join(str(text).lower().split())
            if key in seen:
                continue
            seen.add(key)
            result.append(claim)
        return result

    # ============================================================
    # COMPARISON HELPERS
    # ============================================================

    @staticmethod
    def _is_comparison_question(question):
        q = str(question or "").lower()
        terms = (
            "compare", "comparison", "comparative", "difference",
            "differences", "similarity", "similarities",
            "both papers", "both studies", "all papers",
            "all the papers", "each paper", "across papers",
            "across studies", "between papers", "between studies",
            "in common", "shared",
        )
        return any(term in q for term in terms)

    def _get_available_chunks(self):
        candidates = [
            self.task_retriever,
            getattr(self.task_retriever, "hybrid_retriever", None),
        ]
        hybrid = getattr(self.task_retriever, "hybrid_retriever", None)
        if hybrid is not None:
            candidates.extend([
                getattr(hybrid, "bm25_retriever", None),
                getattr(hybrid, "bm25", None),
                getattr(hybrid, "vector_retriever", None),
            ])

        for candidate in candidates:
            chunks = getattr(candidate, "chunks", None)
            if chunks:
                return list(chunks)
        return []

    def _get_available_paper_ids(self):
        result = set()
        for chunk in self._get_available_chunks():
            paper_id = (
                chunk.get("paper_id")
                if isinstance(chunk, dict)
                else getattr(chunk, "paper_id", None)
            )
            if paper_id:
                result.add(str(paper_id))
        return result

    @staticmethod
    def _claim_paper_id(claim, evidence):
        if isinstance(claim, dict):
            direct = claim.get("paper_id")
            evidence_ids = claim.get("evidence_ids", [])
            citations = claim.get("citations", [])
        else:
            direct = getattr(claim, "paper_id", None)
            evidence_ids = getattr(claim, "evidence_ids", [])
            citations = getattr(claim, "citations", [])

        if direct:
            return str(direct)

        if citations:
            first = citations[0]
            value = (
                first.get("paper_id")
                if isinstance(first, dict)
                else getattr(first, "paper_id", None)
            )
            if value:
                return str(value)

        evidence_map = {
            str(item.get("chunk_id")): str(item.get("paper_id"))
            for item in evidence
            if item.get("chunk_id") and item.get("paper_id")
        }
        for evidence_id in evidence_ids or []:
            if str(evidence_id) in evidence_map:
                return evidence_map[str(evidence_id)]
        return None

    def _claim_paper_ids(self, claims, evidence):
        return {
            paper_id
            for paper_id in (
                self._claim_paper_id(claim, evidence)
                for claim in claims
            )
            if paper_id
        }

    def _apply_comparison_coverage(
        self,
        confidence_result,
        claims,
        evidence,
    ):
        available = self._get_available_paper_ids()
        represented = self._claim_paper_ids(claims, evidence)

        if not available:
            return

        coverage = len(available & represented) / len(available)
        confidence_result["paper_coverage"] = round(coverage * 100.0, 2)
        confidence_result.setdefault("components", {})
        confidence_result["components"]["paper_coverage"] = round(
            coverage * 100.0,
            2,
        )

        base = float(confidence_result.get("score", 0.0))
        adjusted = base * (0.55 + 0.45 * coverage)

        if coverage < 1.0:
            adjusted = min(adjusted, 74.99)
            confidence_result["explanation"] = (
                "The answer is grounded, but not every loaded paper "
                "contributed grounded evidence to this comparison."
            )

        confidence_result["score"] = round(
            max(0.0, min(100.0, adjusted)),
            2,
        )

        score = confidence_result["score"]
        confidence_result["label"] = (
            "HIGH" if score >= 85
            else "MEDIUM" if score >= 60
            else "LOW"
        )

    @staticmethod
    def _build_claim_verification_text(claims):
        texts = []
        for claim in claims:
            text = (
                claim.get("claim") if isinstance(claim, dict)
                else getattr(claim, "claim", None)
            ) or (
                claim.get("text") if isinstance(claim, dict)
                else getattr(claim, "text", None)
            ) or ""
            text = str(text).strip()
            if text:
                texts.append(text)
        return "\n".join(texts)

    # ============================================================
    # OUTPUT / DEBUG
    # ============================================================

    @staticmethod
    def _build_evidence_output(evidence):
        fields = (
            "paper_id", "paper_title", "page_start", "page_end",
            "section", "chunk_id", "text", "task_score", "rrf_score",
            "reranker_score", "combined_score",
        )
        return [
            {field: item.get(field, "" if field in {"paper_id", "paper_title", "section", "chunk_id", "text"} else 0.0)
             for field in fields}
            for item in evidence
        ]

    @staticmethod
    def _print_evidence(evidence, task):
        print("\n" + "=" * 80)
        print("EVIDENCE SENT TO CLAIM GROUNDER")
        print("=" * 80)
        print("Task:", task)
        print("Evidence count:", len(evidence))

        for index, item in enumerate(evidence, start=1):
            print(f"\nEVIDENCE {index}")
            print("-" * 80)
            print("Paper:", item.get("paper_id", ""))
            print("Chunk:", item.get("chunk_id", ""))
            print("Section:", item.get("section", ""))
            print(
                "Pages:",
                item.get("page_start", 0),
                "-",
                item.get("page_end", 0),
            )
            print("Task score:", item.get("task_score", 0.0))
            print("Reranker score:", item.get("reranker_score", 0.0))
            print("Combined score:", item.get("combined_score", 0.0))

    def _empty_result(
        self,
        answer,
        task,
        task_scores=None,
        evidence=None,
    ):
        return {
            "answer": answer,
            "task": task,
            "claims": [],
            "evidence": self._build_evidence_output(evidence or []),
            "task_scores": task_scores or {},
            "hallucination": {
                "supported": False,
                "hallucination_detected": False,
                "support_score": 0.0,
                "claims": [],
            },
            "citations": [],
            "sources": [],
            "confidence": {
                "score": 0.0,
                "label": "LOW",
            },
        }

